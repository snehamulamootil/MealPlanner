import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MealPlannerComponent } from './meal-planner/meal-planner.component';
import { RecipeListComponent } from './recipes/recipe-list/recipe-list.component';
import { RecipeDetailComponent } from './recipes/recipe-detail/recipe-detail.component';
import { GroceryListComponent } from './grocery/grocery-list/grocery-list.component';
import { NutritionDashboardComponent } from './nutrition/nutrition-dashboard/nutrition-dashboard.component';
import { VoiceControlComponent } from './voice/voice-control/voice-control.component';
import { AuthGuard } from './core/guards/auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'meal-planner',
    component: MealPlannerComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'recipes',
    component: RecipeListComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'recipes/:id',
    component: RecipeDetailComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'grocery-lists',
    component: GroceryListComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'nutrition',
    component: NutritionDashboardComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'voice-control',
    component: VoiceControlComponent,
    canActivate: [AuthGuard]
  },
  { path: '**', redirectTo: '/dashboard' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
