import { Component, OnInit } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { MealPlanService, Recipe, MealPlan, PlannedMeal } from '../core/services/meal-plan.service';

@Component({
  selector: 'app-meal-planner',
  template: `
    <div class="meal-planner-container">
      <div class="planner-header">
        <h1>Weekly Meal Planner</h1>
        <div class="header-actions">
          <mat-form-field appearance="outline">
            <mat-label>Week of</mat-label>
            <input matInput [matDatepicker]="picker" [(ngModel)]="selectedWeek">
            <mat-datepicker-toggle matSuffix [for]="picker"></mat-datepicker-toggle>
            <mat-datepicker #picker></mat-datepicker>
          </mat-form-field>
          <button mat-raised-button color="primary" (click)="generateShoppingList()">
            <mat-icon>shopping_cart</mat-icon>
            Generate Shopping List
          </button>
        </div>
      </div>

      <div class="planner-layout">
        <!-- Recipe Library -->
        <div class="recipe-library">
          <mat-card>
            <mat-card-header>
              <mat-card-title>Recipe Library</mat-card-title>
            </mat-card-header>
            <mat-card-content>
              <mat-form-field appearance="outline" class="search-field">
                <mat-label>Search recipes</mat-label>
                <input matInput [(ngModel)]="searchQuery" (input)="filterRecipes()">
                <mat-icon matSuffix>search</mat-icon>
              </mat-form-field>

              <div class="recipe-filters">
                <mat-chip-listbox [(ngModel)]="selectedMealType">
                  <mat-chip-option value="">All</mat-chip-option>
                  <mat-chip-option value="breakfast">Breakfast</mat-chip-option>
                  <mat-chip-option value="lunch">Lunch</mat-chip-option>
                  <mat-chip-option value="dinner">Dinner</mat-chip-option>
                  <mat-chip-option value="snack">Snack</mat-chip-option>
                </mat-chip-listbox>
              </div>

              <div class="recipe-list"
                   cdkDropList
                   #recipeList="cdkDropList"
                   [cdkDropListData]="filteredRecipes"
                   [cdkDropListConnectedTo]="dropLists"
                   (cdkDropListDropped)="drop($event)">
                <div class="recipe-item"
                     *ngFor="let recipe of filteredRecipes"
                     cdkDrag
                     [cdkDragData]="recipe">
                  <mat-card class="recipe-card">
                    <img mat-card-image [src]="recipe.image || 'assets/default-recipe.jpg'"
                         [alt]="recipe.title" class="recipe-image">
                    <mat-card-content>
                      <h4>{{recipe.title}}</h4>
                      <div class="recipe-meta">
                        <span class="recipe-time">
                          <mat-icon>schedule</mat-icon>
                          {{recipe.prep_time + recipe.cook_time}}min
                        </span>
                        <span class="recipe-calories">
                          <mat-icon>local_fire_department</mat-icon>
                          {{recipe.total_calories}} cal
                        </span>
                      </div>
                      <mat-chip [color]="getDifficultyColor(recipe.difficulty)">
                        {{recipe.difficulty}}
                      </mat-chip>
                    </mat-card-content>
                  </mat-card>
                </div>
              </div>
            </mat-card-content>
          </mat-card>
        </div>

        <!-- Weekly Calendar -->
        <div class="weekly-calendar">
          <div class="calendar-grid">
            <div class="time-header"></div>
            <div class="day-header" *ngFor="let day of weekDays">
              <h3>{{day.name}}</h3>
              <p>{{day.date | date:'MMM d'}}</p>
            </div>

            <!-- Meal Type Rows -->
            <ng-container *ngFor="let mealType of mealTypes">
              <div class="meal-type-label">
                <h4>{{mealType | titlecase}}</h4>
              </div>

              <div class="meal-slot"
                   *ngFor="let day of weekDays"
                   cdkDropList
                   [id]="day.key + '-' + mealType"
                   [cdkDropListData]="getMealsForSlot(day.key, mealType)"
                   [cdkDropListConnectedTo]="dropLists"
                   (cdkDropListDropped)="drop($event)">

                <div class="planned-meal"
                     *ngFor="let meal of getMealsForSlot(day.key, mealType)"
                     cdkDrag
                     [cdkDragData]="meal">
                  <mat-card class="meal-card">
                    <mat-card-content>
                      <h5>{{meal.recipe.title}}</h5>
                      <div class="meal-details">
                        <span>{{meal.servings}} serving(s)</span>
                        <span>{{meal.recipe.total_calories * meal.servings}} cal</span>
                      </div>
                      <button mat-icon-button
                              color="warn"
                              class="remove-meal"
                              (click)="removeMeal(meal)">
                        <mat-icon>close</mat-icon>
                      </button>
                    </mat-card-content>
                  </mat-card>
                </div>

                <div class="empty-slot" *ngIf="getMealsForSlot(day.key, mealType).length === 0">
                  <p>Drop recipe here</p>
                </div>
              </div>
            </ng-container>
          </div>
        </div>
      </div>

      <!-- Nutrition Summary -->
      <div class="nutrition-summary">
        <mat-card>
          <mat-card-header>
            <mat-card-title>Weekly Nutrition Summary</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="nutrition-stats">
              <div class="stat">
                <h4>{{getTotalCalories()}}</h4>
                <p>Total Calories</p>
              </div>
              <div class="stat">
                <h4>{{getAverageCalories()}}</h4>
                <p>Daily Average</p>
              </div>
              <div class="stat">
                <h4>{{getTotalMeals()}}</h4>
                <p>Planned Meals</p>
              </div>
              <div class="stat">
                <h4>${{getEstimatedCost()}}</h4>
                <p>Estimated Cost</p>
              </div>
            </div>
          </mat-card-content>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .meal-planner-container {
      padding: 24px;
      max-width: 1400px;
      margin: 0 auto;
    }
    .planner-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
    }
    .header-actions {
      display: flex;
      gap: 16px;
      align-items: center;
    }
    .planner-layout {
      display: grid;
      grid-template-columns: 300px 1fr;
      gap: 24px;
      margin-bottom: 24px;
    }
    .recipe-library {
      height: fit-content;
    }
    .search-field {
      width: 100%;
      margin-bottom: 16px;
    }
    .recipe-filters {
      margin-bottom: 16px;
    }
    .recipe-list {
      max-height: 600px;
      overflow-y: auto;
    }
    .recipe-item {
      margin-bottom: 12px;
      cursor: grab;
    }
    .recipe-item:active {
      cursor: grabbing;
    }
    .recipe-card {
      transition: transform 0.2s;
    }
    .recipe-card:hover {
      transform: translateY(-2px);
    }
    .recipe-image {
      height: 120px;
      object-fit: cover;
    }
    .recipe-meta {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 8px 0;
      font-size: 12px;
      color: #666;
    }
    .recipe-time, .recipe-calories {
      display: flex;
      align-items: center;
      gap: 4px;
    }
    .recipe-time mat-icon, .recipe-calories mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
    }
    .weekly-calendar {
      overflow-x: auto;
    }
    .calendar-grid {
      display: grid;
      grid-template-columns: 100px repeat(7, 1fr);
      grid-template-rows: 60px repeat(4, 120px);
      gap: 8px;
      min-width: 800px;
    }
    .time-header {
      grid-column: 1;
      grid-row: 1;
    }
    .day-header {
      text-align: center;
      padding: 8px;
      background: #f5f5f5;
      border-radius: 8px;
    }
    .day-header h3 {
      margin: 0;
      font-size: 16px;
    }
    .day-header p {
      margin: 4px 0 0 0;
      font-size: 12px;
      color: #666;
    }
    .meal-type-label {
      display: flex;
      align-items: center;
      justify-content: center;
      background: #e3f2fd;
      border-radius: 8px;
      padding: 8px;
    }
    .meal-type-label h4 {
      margin: 0;
      font-size: 14px;
      color: #1976d2;
    }
    .meal-slot {
      border: 2px dashed #ddd;
      border-radius: 8px;
      padding: 8px;
      min-height: 100px;
      position: relative;
    }
    .meal-slot.cdk-drop-list-dragging {
      background: #f0f8ff;
      border-color: #2196f3;
    }
    .empty-slot {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100%;
      color: #999;
      font-style: italic;
    }
    .meal-card {
      margin-bottom: 8px;
      position: relative;
      cursor: grab;
    }
    .meal-card:active {
      cursor: grabbing;
    }
    .meal-card h5 {
      margin: 0 0 8px 0;
      font-size: 14px;
    }
    .meal-details {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      color: #666;
    }
    .remove-meal {
      position: absolute;
      top: 4px;
      right: 4px;
      width: 20px;
      height: 20px;
    }
    .remove-meal mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
    }
    .nutrition-summary {
      grid-column: 1 / -1;
    }
    .nutrition-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 24px;
      text-align: center;
    }
    .stat h4 {
      margin: 0;
      font-size: 24px;
      color: #3f51b5;
    }
    .stat p {
      margin: 4px 0 0 0;
      color: #666;
    }
    .cdk-drag-preview {
      box-sizing: border-box;
      border-radius: 4px;
      box-shadow: 0 5px 5px -3px rgba(0, 0, 0, 0.2);
    }
    .cdk-drag-placeholder {
      opacity: 0;
    }
    .cdk-drag-animating {
      transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);
    }
  `]
})
export class MealPlannerComponent implements OnInit {
  selectedWeek = new Date();
  searchQuery = '';
  selectedMealType = '';

  weekDays = [
    { key: 'monday', name: 'Monday', date: new Date() },
    { key: 'tuesday', name: 'Tuesday', date: new Date() },
    { key: 'wednesday', name: 'Wednesday', date: new Date() },
    { key: 'thursday', name: 'Thursday', date: new Date() },
    { key: 'friday', name: 'Friday', date: new Date() },
    { key: 'saturday', name: 'Saturday', date: new Date() },
    { key: 'sunday', name: 'Sunday', date: new Date() }
  ];

  mealTypes = ['breakfast', 'lunch', 'dinner', 'snack'];

  recipes: Recipe[] = [];
  filteredRecipes: Recipe[] = [];
  plannedMeals: PlannedMeal[] = [];
  currentMealPlan: MealPlan | null = null;
  dropLists: string[] = [];
  isLoading = false;

  constructor(
    private dialog: MatDialog,
    private toastr: ToastrService,
    private mealPlanService: MealPlanService
  ) {}

  ngOnInit(): void {
    this.setupDropLists();
    this.calculateWeekDates();
    this.loadRecipes();
    this.loadCurrentMealPlan();
  }

  loadRecipes(): void {
    this.isLoading = true;
    this.mealPlanService.getRecipes().subscribe({
      next: (recipes) => {
        this.recipes = recipes;
        this.filteredRecipes = [...this.recipes];
        this.isLoading = false;
      },
      error: (error) => {
        this.toastr.error('Failed to load recipes');
        this.isLoading = false;
      }
    });
  }

  loadCurrentMealPlan(): void {
    this.mealPlanService.getMealPlans().subscribe({
      next: (mealPlans) => {
        // Get the active meal plan or create a new one
        this.currentMealPlan = mealPlans.find(plan => plan.is_active) || null;
        if (this.currentMealPlan) {
          this.plannedMeals = this.currentMealPlan.planned_meals || [];
        } else {
          this.createNewMealPlan();
        }
      },
      error: (error) => {
        this.toastr.error('Failed to load meal plans');
      }
    });
  }

  createNewMealPlan(): void {
    const startDate = this.getWeekStartDate();
    const endDate = new Date(startDate);
    endDate.setDate(startDate.getDate() + 6);

    const newMealPlan = {
      name: `Week of ${startDate.toDateString()}`,
      start_date: startDate.toISOString().split('T')[0],
      end_date: endDate.toISOString().split('T')[0],
      is_active: true
    };

    this.mealPlanService.createMealPlan(newMealPlan).subscribe({
      next: (mealPlan) => {
        this.currentMealPlan = mealPlan;
        this.plannedMeals = [];
        this.toastr.success('New meal plan created');
      },
      error: (error) => {
        this.toastr.error('Failed to create meal plan');
      }
    });
  }

  setupDropLists(): void {
    this.dropLists = ['recipeList'];
    this.weekDays.forEach(day => {
      this.mealTypes.forEach(mealType => {
        this.dropLists.push(`${day.key}-${mealType}`);
      });
    });
  }

  calculateWeekDates(): void {
    const startOfWeek = new Date(this.selectedWeek);
    const day = startOfWeek.getDay();
    const diff = startOfWeek.getDate() - day + (day === 0 ? -6 : 1);
    startOfWeek.setDate(diff);

    this.weekDays.forEach((weekDay, index) => {
      const date = new Date(startOfWeek);
      date.setDate(startOfWeek.getDate() + index);
      weekDay.date = date;
    });
  }

  filterRecipes(): void {
    this.filteredRecipes = this.recipes.filter(recipe => {
      const matchesSearch = !this.searchQuery ||
        recipe.title.toLowerCase().includes(this.searchQuery.toLowerCase());
      const matchesMealType = !this.selectedMealType ||
        recipe.meal_type === this.selectedMealType;
      return matchesSearch && matchesMealType;
    });
  }

  drop(event: CdkDragDrop<any[]>): void {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      // Moving from recipe library to meal slot
      if (event.previousContainer.id === 'recipeList') {
        const recipe = event.previousContainer.data[event.previousIndex];
        const [day, mealType] = event.container.id.split('-');

        if (!this.currentMealPlan) {
          this.toastr.error('Please create a meal plan first');
          return;
        }

        const dragData = {
          recipe_id: recipe.id,
          target_day: day,
          target_meal_type: mealType,
          servings: 1,
          date: this.getDateForDay(day).toISOString().split('T')[0]
        };

        this.mealPlanService.dragDropMeal(this.currentMealPlan.id, dragData).subscribe({
          next: (response) => {
            this.loadCurrentMealPlan(); // Refresh the meal plan
            this.toastr.success(response.message);
          },
          error: (error) => {
            this.toastr.error('Failed to add meal to plan');
          }
        });
      }
    }
  }

  removeMeal(meal: PlannedMeal): void {
    if (!this.currentMealPlan || !meal.id) return;

    this.mealPlanService.removePlannedMeal(this.currentMealPlan.id, meal.id).subscribe({
      next: () => {
        this.loadCurrentMealPlan(); // Refresh the meal plan
        this.toastr.info('Meal removed from plan');
      },
      error: (error) => {
        this.toastr.error('Failed to remove meal');
      }
    });
  }

  generateShoppingList(): void {
    if (!this.currentMealPlan) {
      this.toastr.error('No meal plan available');
      return;
    }

    this.mealPlanService.generateShoppingList(this.currentMealPlan.id).subscribe({
      next: (response) => {
        this.toastr.success('Shopping list generated successfully!');
        // Optionally navigate to grocery list page
      },
      error: (error) => {
        this.toastr.error('Failed to generate shopping list');
      }
    });
  }

  getDateForDay(dayKey: string): Date {
    const dayIndex = this.weekDays.findIndex(day => day.key === dayKey);
    return this.weekDays[dayIndex].date;
  }

  getWeekStartDate(): Date {
    const date = new Date(this.selectedWeek);
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    date.setDate(diff);
    return date;
  }

  getDifficultyColor(difficulty: string): string {
    switch (difficulty) {
      case 'easy': return 'primary';
      case 'medium': return 'accent';
      case 'hard': return 'warn';
      default: return 'primary';
    }
  }

  getTotalCalories(): number {
    return this.plannedMeals.reduce((total, meal) =>
      total + (meal.recipe.total_calories * meal.servings), 0
    );
  }

  getAverageCalories(): number {
    const total = this.getTotalCalories();
    return Math.round(total / 7);
  }

  getTotalMeals(): number {
    return this.plannedMeals.length;
  }

  getEstimatedCost(): number {
    // Mock calculation - in real app, this would come from recipe cost data
    return Math.round(this.plannedMeals.length * 8.5);
  }

  generateShoppingList(): void {
    // TODO: Implement shopping list generation
    this.toastr.success('Shopping list generated successfully!');
  }
}
