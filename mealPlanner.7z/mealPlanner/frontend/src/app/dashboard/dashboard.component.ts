import { Component, OnInit } from '@angular/core';
import { AuthService, User } from '../core/services/auth.service';

@Component({
  selector: 'app-dashboard',
  template: `
    <div class="dashboard-container">
      <div class="dashboard-header">
        <h1>Welcome back, {{user?.first_name}}!</h1>
        <p>Here's your meal planning overview</p>
      </div>

      <div class="dashboard-grid">
        <!-- Quick Stats -->
        <div class="stat-cards">
          <mat-card class="stat-card">
            <mat-card-content>
              <div class="stat-content">
                <mat-icon class="stat-icon">restaurant_menu</mat-icon>
                <div>
                  <h3>{{weeklyMeals}}</h3>
                  <p>Meals Planned</p>
                </div>
              </div>
            </mat-card-content>
          </mat-card>

          <mat-card class="stat-card">
            <mat-card-content>
              <div class="stat-content">
                <mat-icon class="stat-icon">shopping_cart</mat-icon>
                <div>
                  <h3>{{groceryItems}}</h3>
                  <p>Grocery Items</p>
                </div>
              </div>
            </mat-card-content>
          </mat-card>

          <mat-card class="stat-card">
            <mat-card-content>
              <div class="stat-content">
                <mat-icon class="stat-icon">local_dining</mat-icon>
                <div>
                  <h3>{{dailyCalories}}</h3>
                  <p>Today's Calories</p>
                </div>
              </div>
            </mat-card-content>
          </mat-card>

          <mat-card class="stat-card">
            <mat-card-content>
              <div class="stat-content">
                <mat-icon class="stat-icon">attach_money</mat-icon>
                <div>
                  <h3>${{weeklyBudget}}</h3>
                  <p>Weekly Budget</p>
                </div>
              </div>
            </mat-card-content>
          </mat-card>
        </div>

        <!-- Quick Actions -->
        <mat-card class="action-card">
          <mat-card-header>
            <mat-card-title>Quick Actions</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="action-buttons">
              <button mat-raised-button color="primary" routerLink="/meal-planner">
                <mat-icon>calendar_today</mat-icon>
                Plan Meals
              </button>
              <button mat-raised-button color="accent" routerLink="/recipes">
                <mat-icon>add</mat-icon>
                Add Recipe
              </button>
              <button mat-raised-button routerLink="/grocery-lists">
                <mat-icon>shopping_cart</mat-icon>
                Grocery List
              </button>
              <button mat-raised-button routerLink="/voice-control">
                <mat-icon>mic</mat-icon>
                Voice Commands
              </button>
            </div>
          </mat-card-content>
        </mat-card>

        <!-- Today's Meals -->
        <mat-card class="meals-card">
          <mat-card-header>
            <mat-card-title>Today's Meals</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="meal-timeline">
              <div class="meal-item" *ngFor="let meal of todaysMeals">
                <div class="meal-time">{{meal.time}}</div>
                <div class="meal-info">
                  <h4>{{meal.name}}</h4>
                  <p>{{meal.calories}} calories</p>
                </div>
              </div>
              <div class="meal-item empty" *ngIf="todaysMeals.length === 0">
                <p>No meals planned for today</p>
                <button mat-button color="primary" routerLink="/meal-planner">
                  Plan Now
                </button>
              </div>
            </div>
          </mat-card-content>
        </mat-card>

        <!-- Nutrition Progress -->
        <mat-card class="nutrition-card">
          <mat-card-header>
            <mat-card-title>Nutrition Progress</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="nutrition-progress">
              <div class="progress-item">
                <span>Calories</span>
                <mat-progress-bar mode="determinate" [value]="calorieProgress"></mat-progress-bar>
                <span>{{dailyCalories}}/{{targetCalories}}</span>
              </div>
              <div class="progress-item">
                <span>Protein</span>
                <mat-progress-bar mode="determinate" [value]="proteinProgress" color="accent"></mat-progress-bar>
                <span>{{dailyProtein}}g/{{targetProtein}}g</span>
              </div>
              <div class="progress-item">
                <span>Carbs</span>
                <mat-progress-bar mode="determinate" [value]="carbProgress" color="warn"></mat-progress-bar>
                <span>{{dailyCarbs}}g/{{targetCarbs}}g</span>
              </div>
            </div>
          </mat-card-content>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container {
      padding: 24px;
      max-width: 1200px;
      margin: 0 auto;
    }
    .dashboard-header {
      margin-bottom: 32px;
    }
    .dashboard-header h1 {
      margin: 0;
      color: #333;
    }
    .dashboard-header p {
      margin: 8px 0 0 0;
      color: #666;
    }
    .dashboard-grid {
      display: grid;
      gap: 24px;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    }
    .stat-cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      grid-column: 1 / -1;
    }
    .stat-card {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }
    .stat-content {
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .stat-icon {
      font-size: 32px;
      width: 32px;
      height: 32px;
    }
    .stat-content h3 {
      margin: 0;
      font-size: 24px;
      font-weight: 600;
    }
    .stat-content p {
      margin: 4px 0 0 0;
      opacity: 0.9;
    }
    .action-buttons {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 12px;
    }
    .action-buttons button {
      height: 48px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .meal-timeline {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    .meal-item {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 12px;
      border-radius: 8px;
      background: #f8f9fa;
    }
    .meal-item.empty {
      justify-content: center;
      flex-direction: column;
      padding: 32px;
      text-align: center;
    }
    .meal-time {
      font-weight: 600;
      color: #3f51b5;
      min-width: 80px;
    }
    .meal-info h4 {
      margin: 0;
      font-size: 16px;
    }
    .meal-info p {
      margin: 4px 0 0 0;
      color: #666;
      font-size: 14px;
    }
    .nutrition-progress {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    .progress-item {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .progress-item span:first-child {
      min-width: 60px;
      font-weight: 500;
    }
    .progress-item mat-progress-bar {
      flex: 1;
    }
    .progress-item span:last-child {
      min-width: 80px;
      font-size: 14px;
      color: #666;
    }
  `]
})
export class DashboardComponent implements OnInit {
  user: User | null = null;

  // Dashboard data
  weeklyMeals = 12;
  groceryItems = 24;
  dailyCalories = 1850;
  weeklyBudget = 120;

  // Today's meals
  todaysMeals = [
    { time: '8:00 AM', name: 'Avocado Toast', calories: 320 },
    { time: '12:30 PM', name: 'Grilled Chicken Salad', calories: 450 },
    { time: '7:00 PM', name: 'Salmon with Quinoa', calories: 580 }
  ];

  // Nutrition targets and progress
  targetCalories = 2200;
  targetProtein = 120;
  targetCarbs = 250;

  dailyProtein = 89;
  dailyCarbs = 195;

  calorieProgress = (this.dailyCalories / this.targetCalories) * 100;
  proteinProgress = (this.dailyProtein / this.targetProtein) * 100;
  carbProgress = (this.dailyCarbs / this.targetCarbs) * 100;

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.user = this.authService.getCurrentUser();
    // TODO: Load actual dashboard data from API
  }
}
