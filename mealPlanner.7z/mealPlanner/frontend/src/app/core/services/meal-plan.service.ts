import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Recipe {
  id: number;
  title: string;
  description: string;
  instructions: string;
  prep_time: number;
  cook_time: number;
  servings: number;
  difficulty: string;
  meal_type: string;
  cuisine_type: string;
  image?: string;
  categories: any[];
  created_by: number;
  created_by_name: string;
  is_public: boolean;
  rating: number;
  recipe_ingredients: any[];
  reviews: any[];
  total_time: number;
  total_calories: number;
  estimated_cost: number;
  is_favorite: boolean;
}

export interface MealPlan {
  id: number;
  name: string;
  start_date: string;
  end_date: string;
  is_active: boolean;
  planned_meals: PlannedMeal[];
  total_estimated_cost: number;
  total_calories: number;
}

export interface PlannedMeal {
  id: number;
  recipe: Recipe;
  recipe_details: Recipe;
  day_of_week: string;
  meal_type: string;
  servings: number;
  date: string;
  notes: string;
  is_completed: boolean;
  estimated_cost: number;
  total_calories: number;
}

@Injectable({
  providedIn: 'root'
})
export class MealPlanService {
  private apiUrl = 'http://localhost:8000/api';

  constructor(private http: HttpClient) {}

  // Recipe methods
  getRecipes(params?: any): Observable<Recipe[]> {
    return this.http.get<Recipe[]>(`${this.apiUrl}/recipes/`, { params });
  }

  getRecipe(id: number): Observable<Recipe> {
    return this.http.get<Recipe>(`${this.apiUrl}/recipes/${id}/`);
  }

  createRecipe(recipe: any): Observable<Recipe> {
    return this.http.post<Recipe>(`${this.apiUrl}/recipes/`, recipe);
  }

  updateRecipe(id: number, recipe: any): Observable<Recipe> {
    return this.http.put<Recipe>(`${this.apiUrl}/recipes/${id}/`, recipe);
  }

  deleteRecipe(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/recipes/${id}/`);
  }

  getRecipeSuggestions(): Observable<Recipe[]> {
    return this.http.get<Recipe[]>(`${this.apiUrl}/recipes/suggestions/`);
  }

  toggleFavoriteRecipe(recipeId: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/recipes/${recipeId}/favorite/`, {});
  }

  // Meal Plan methods
  getMealPlans(): Observable<MealPlan[]> {
    return this.http.get<MealPlan[]>(`${this.apiUrl}/meal-plans/`);
  }

  getMealPlan(id: number): Observable<MealPlan> {
    return this.http.get<MealPlan>(`${this.apiUrl}/meal-plans/${id}/`);
  }

  createMealPlan(mealPlan: any): Observable<MealPlan> {
    return this.http.post<MealPlan>(`${this.apiUrl}/meal-plans/`, mealPlan);
  }

  updateMealPlan(id: number, mealPlan: any): Observable<MealPlan> {
    return this.http.put<MealPlan>(`${this.apiUrl}/meal-plans/${id}/`, mealPlan);
  }

  deleteMealPlan(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/meal-plans/${id}/`);
  }

  // Drag and drop meal functionality
  dragDropMeal(mealPlanId: number, dragData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/meal-plans/${mealPlanId}/drag-drop/`, dragData);
  }

  removePlannedMeal(mealPlanId: number, plannedMealId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/meal-plans/${mealPlanId}/meals/${plannedMealId}/remove/`);
  }

  generateShoppingList(mealPlanId: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/meal-plans/${mealPlanId}/shopping-list/`, {});
  }

  // Categories and ingredients
  getCategories(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/recipes/categories/`);
  }

  getIngredients(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/recipes/ingredients/`);
  }
}
