import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface VoiceCommand {
  id: number;
  transcribed_text: string;
  command_type: string;
  parsed_intent: any;
  status: string;
  confidence_score: number;
  response_text: string;
  execution_result: any;
  processing_time: number;
  created_at: string;
  completed_at: string;
}

export interface VoiceSession {
  session_id: string;
  start_time: string;
  end_time: string;
  commands_count: number;
  successful_commands: number;
  failed_commands: number;
  success_rate: number;
}

@Injectable({
  providedIn: 'root'
})
export class VoiceService {
  private apiUrl = 'http://localhost:8000/api/speech';

  constructor(private http: HttpClient) {}

  // Voice Commands
  getVoiceCommands(): Observable<VoiceCommand[]> {
    return this.http.get<VoiceCommand[]>(`${this.apiUrl}/commands/`);
  }

  processVoiceCommand(audioFile?: File, text?: string): Observable<any> {
    const formData = new FormData();
    if (audioFile) {
      formData.append('audio_file', audioFile);
    }
    if (text) {
      formData.append('text', text);
    }
    return this.http.post(`${this.apiUrl}/process/`, formData);
  }

  // Voice Sessions
  startVoiceSession(): Observable<any> {
    return this.http.post(`${this.apiUrl}/sessions/start/`, {});
  }

  endVoiceSession(sessionId: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/sessions/${sessionId}/end/`, {});
  }

  // Live Speech Recognition
  startLiveSpeechRecognition(options?: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/live-recognition/`, options || {});
  }

  // Voice Preferences
  getVoicePreferences(): Observable<any> {
    return this.http.get(`${this.apiUrl}/preferences/`);
  }

  updateVoicePreferences(preferences: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/preferences/`, preferences);
  }

  // Text to Speech
  textToSpeech(text: string, options?: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/text-to-speech/`, {
      text,
      ...options
    });
  }

  // Analytics
  getVoiceAnalytics(): Observable<any> {
    return this.http.get(`${this.apiUrl}/analytics/`);
  }
}
