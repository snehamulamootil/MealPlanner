import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface GroceryList {
  id: number;
  name: string;
  description: string;
  status: string;
  budget_limit: number;
  store_name: string;
  due_date: string;
  is_shared: boolean;
  items: GroceryItem[];
  total_estimated_cost: number;
  total_actual_cost: number;
  completion_percentage: number;
  is_over_budget: boolean;
}

export interface GroceryItem {
  id: number;
  name: string;
  category_name: string;
  brand: string;
  quantity: number;
  unit: string;
  estimated_price: number;
  actual_price: number;
  priority: string;
  notes: string;
  is_purchased: boolean;
  purchased_at: string;
  added_by_voice: boolean;
  total_estimated_cost: number;
  total_actual_cost: number;
}

export interface Budget {
  id: number;
  period: string;
  amount: number;
  start_date: string;
  end_date: string;
  category_name: string;
  is_active: boolean;
  spent_amount: number;
  remaining_amount: number;
  is_over_budget: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class GroceryService {
  private apiUrl = 'http://localhost:8000/api';

  constructor(private http: HttpClient) {}

  // Grocery Lists
  getGroceryLists(): Observable<GroceryList[]> {
    return this.http.get<GroceryList[]>(`${this.apiUrl}/grocery-lists/`);
  }

  getGroceryList(id: number): Observable<GroceryList> {
    return this.http.get<GroceryList>(`${this.apiUrl}/grocery-lists/${id}/`);
  }

  createGroceryList(groceryList: any): Observable<GroceryList> {
    return this.http.post<GroceryList>(`${this.apiUrl}/grocery-lists/`, groceryList);
  }

  updateGroceryList(id: number, groceryList: any): Observable<GroceryList> {
    return this.http.put<GroceryList>(`${this.apiUrl}/grocery-lists/${id}/`, groceryList);
  }

  deleteGroceryList(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/grocery-lists/${id}/`);
  }

  // Grocery Items
  getGroceryItems(groceryListId: number): Observable<GroceryItem[]> {
    return this.http.get<GroceryItem[]>(`${this.apiUrl}/grocery-lists/${groceryListId}/items/`);
  }

  addGroceryItem(groceryListId: number, item: any): Observable<GroceryItem> {
    return this.http.post<GroceryItem>(`${this.apiUrl}/grocery-lists/${groceryListId}/items/`, item);
  }

  updateGroceryItem(itemId: number, item: any): Observable<GroceryItem> {
    return this.http.put<GroceryItem>(`${this.apiUrl}/grocery-lists/items/${itemId}/`, item);
  }

  deleteGroceryItem(itemId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/grocery-lists/items/${itemId}/`);
  }

  markItemPurchased(itemId: number, actualPrice?: number): Observable<any> {
    const data = actualPrice ? { actual_price: actualPrice } : {};
    return this.http.post(`${this.apiUrl}/grocery-lists/items/${itemId}/purchase/`, data);
  }

  // Voice functionality
  addVoiceGroceryItem(groceryListId: number, textInput: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/grocery-lists/voice/add-item/`, {
      grocery_list_id: groceryListId,
      text_input: textInput
    });
  }

  // Budgets
  getBudgets(): Observable<Budget[]> {
    return this.http.get<Budget[]>(`${this.apiUrl}/grocery-lists/budgets/`);
  }

  getBudgetOverview(): Observable<any> {
    return this.http.get(`${this.apiUrl}/grocery-lists/budgets/overview/`);
  }

  createBudget(budget: any): Observable<Budget> {
    return this.http.post<Budget>(`${this.apiUrl}/grocery-lists/budgets/`, budget);
  }

  // Categories and Stores
  getCategories(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/grocery-lists/categories/`);
  }

  getStores(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/grocery-lists/stores/`);
  }
}
