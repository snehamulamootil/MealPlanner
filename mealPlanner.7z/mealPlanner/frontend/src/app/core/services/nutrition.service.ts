import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface NutritionGoal {
  id: number;
  goal_type: string;
  target_calories: number;
  target_protein: number;
  target_carbs: number;
  target_fat: number;
  target_fiber: number;
  target_sugar: number;
  target_sodium: number;
  is_active: boolean;
}

export interface DailyNutrition {
  id: number;
  date: string;
  calories_consumed: number;
  protein_consumed: number;
  carbs_consumed: number;
  fat_consumed: number;
  fiber_consumed: number;
  sugar_consumed: number;
  sodium_consumed: number;
  water_intake: number;
  goal_progress: any;
}

export interface MealLog {
  id: number;
  recipe_details: any;
  meal_type: string;
  servings: number;
  date: string;
  logged_at: string;
  notes: string;
  calories: number;
}

@Injectable({
  providedIn: 'root'
})
export class NutritionService {
  private apiUrl = 'http://localhost:8000/api/nutrition';

  constructor(private http: HttpClient) {}

  // Nutrition Goals
  getNutritionGoals(): Observable<NutritionGoal[]> {
    return this.http.get<NutritionGoal[]>(`${this.apiUrl}/goals/`);
  }

  createNutritionGoal(goal: any): Observable<NutritionGoal> {
    return this.http.post<NutritionGoal>(`${this.apiUrl}/goals/`, goal);
  }

  autoCalculateGoals(): Observable<any> {
    return this.http.post(`${this.apiUrl}/goals/auto-calculate/`, {});
  }

  // Daily Nutrition
  getDailyNutrition(): Observable<DailyNutrition[]> {
    return this.http.get<DailyNutrition[]>(`${this.apiUrl}/daily/`);
  }

  // Meal Logs
  getMealLogs(): Observable<MealLog[]> {
    return this.http.get<MealLog[]>(`${this.apiUrl}/meals/`);
  }

  logMeal(mealData: any): Observable<MealLog> {
    return this.http.post<MealLog>(`${this.apiUrl}/meals/`, mealData);
  }

  // Water Intake
  logWaterIntake(amount: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/water/`, { amount });
  }

  // Dashboard Data
  getNutritionDashboard(): Observable<any> {
    return this.http.get(`${this.apiUrl}/dashboard/`);
  }

  // Reports
  generateNutritionReport(reportType: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/reports/generate/`, { report_type: reportType });
  }
}
