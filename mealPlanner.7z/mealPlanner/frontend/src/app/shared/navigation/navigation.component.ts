import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService, User } from '../../core/services/auth.service';

@Component({
  selector: 'app-navigation',
  template: `
    <mat-sidenav-container class="sidenav-container">
      <mat-sidenav mode="side" opened class="sidenav">
        <div class="nav-header">
          <mat-icon class="app-icon">restaurant_menu</mat-icon>
          <h3>Meal Planner</h3>
        </div>

        <mat-nav-list>
          <a mat-list-item routerLink="/dashboard" routerLinkActive="active">
            <mat-icon>dashboard</mat-icon>
            <span>Dashboard</span>
          </a>

          <a mat-list-item routerLink="/meal-planner" routerLinkActive="active">
            <mat-icon>calendar_today</mat-icon>
            <span>Meal Planner</span>
          </a>

          <a mat-list-item routerLink="/recipes" routerLinkActive="active">
            <mat-icon>menu_book</mat-icon>
            <span>Recipes</span>
          </a>

          <a mat-list-item routerLink="/grocery-lists" routerLinkActive="active">
            <mat-icon>shopping_cart</mat-icon>
            <span>Grocery Lists</span>
          </a>

          <a mat-list-item routerLink="/nutrition" routerLinkActive="active">
            <mat-icon>local_dining</mat-icon>
            <span>Nutrition</span>
          </a>

          <a mat-list-item routerLink="/voice-control" routerLinkActive="active">
            <mat-icon>mic</mat-icon>
            <span>Voice Control</span>
          </a>

          <mat-divider></mat-divider>

          <a mat-list-item (click)="logout()">
            <mat-icon>logout</mat-icon>
            <span>Logout</span>
          </a>
        </mat-nav-list>

        <div class="user-info">
          <mat-card class="user-card">
            <div class="user-avatar">
              <mat-icon>account_circle</mat-icon>
            </div>
            <div class="user-details">
              <p class="user-name">{{user?.first_name}} {{user?.last_name}}</p>
              <p class="user-email">{{user?.email}}</p>
            </div>
          </mat-card>
        </div>
      </mat-sidenav>
    </mat-sidenav-container>
  `,
  styles: [`
    .sidenav-container {
      height: 100vh;
    }
    .sidenav {
      width: 250px;
      background: #f5f5f5;
      border-right: 1px solid #ddd;
    }
    .nav-header {
      padding: 20px;
      text-align: center;
      background: #3f51b5;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }
    .app-icon {
      font-size: 24px;
    }
    .nav-header h3 {
      margin: 0;
      font-weight: 500;
    }
    .mat-nav-list .mat-list-item {
      height: 48px;
      margin: 4px 8px;
      border-radius: 4px;
    }
    .mat-nav-list .mat-list-item:hover {
      background-color: #e3f2fd;
    }
    .mat-nav-list .mat-list-item.active {
      background-color: #bbdefb;
      color: #1976d2;
    }
    .mat-nav-list .mat-list-item mat-icon {
      margin-right: 16px;
      color: #666;
    }
    .mat-nav-list .mat-list-item.active mat-icon {
      color: #1976d2;
    }
    .user-info {
      position: absolute;
      bottom: 20px;
      left: 10px;
      right: 10px;
    }
    .user-card {
      padding: 12px;
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .user-avatar mat-icon {
      font-size: 32px;
      width: 32px;
      height: 32px;
      color: #666;
    }
    .user-details {
      flex: 1;
      min-width: 0;
    }
    .user-name {
      margin: 0;
      font-weight: 500;
      font-size: 14px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .user-email {
      margin: 0;
      font-size: 12px;
      color: #666;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  `]
})
export class NavigationComponent {
  @Input() user: User | null = null;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  logout(): void {
    this.authService.logout();
  }
}
