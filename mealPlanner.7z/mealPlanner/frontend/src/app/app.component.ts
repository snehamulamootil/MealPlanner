import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './core/services/auth.service';

@Component({
  selector: 'app-root',
  template: `
    <div class="app-container">
      <app-navigation *ngIf="authService.isAuthenticated()" [user]="authService.getCurrentUser()"></app-navigation>
      <main class="main-content" [class.with-nav]="authService.isAuthenticated()">
        <router-outlet></router-outlet>
      </main>
    </div>
  `,
  styles: [`
    .app-container {
      height: 100vh;
      display: flex;
    }
    .main-content {
      flex: 1;
      overflow-y: auto;
    }
    .main-content.with-nav {
      margin-left: 250px;
    }
  `]
})
export class AppComponent {
  title = 'Meal & Grocery Planner';

  constructor(
    public authService: AuthService,
    private router: Router
  ) {}
}
