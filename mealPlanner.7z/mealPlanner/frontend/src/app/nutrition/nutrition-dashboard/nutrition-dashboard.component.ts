import { Component, OnInit } from '@angular/core';
import { NutritionService, NutritionGoal, DailyNutrition, MealLog } from '../../core/services/nutrition.service';
import { ToastrService } from 'ngx-toastr';
import { ChartConfiguration, ChartData, ChartType } from 'chart.js';

@Component({
  selector: 'app-nutrition-dashboard',
  template: `
    <div class="nutrition-container">
      <div class="nutrition-header">
        <h1>Nutrition Dashboard</h1>
        <div class="header-actions">
          <button mat-raised-button color="primary" (click)="autoCalculateGoals()">
            <mat-icon>calculate</mat-icon>
            Auto Calculate Goals
          </button>
          <button mat-raised-button color="accent" (click)="generateReport()">
            <mat-icon>assessment</mat-icon>
            Generate Report
          </button>
        </div>
      </div>

      <!-- Today's Progress -->
      <div class="today-progress" *ngIf="dashboardData">
        <mat-card>
          <mat-card-header>
            <mat-card-title>Today's Nutrition Progress</mat-card-title>
            <mat-card-subtitle>{{getCurrentDate()}}</mat-card-subtitle>
          </mat-card-header>

          <mat-card-content>
            <div class="progress-grid">
              <!-- Calories -->
              <div class="progress-item">
                <div class="progress-header">
                  <h3>Calories</h3>
                  <span class="progress-values">
                    {{dashboardData.today_nutrition?.calories_consumed || 0}} /
                    {{dashboardData.active_goal?.target_calories || 0}}
                  </span>
                </div>
                <mat-progress-bar mode="determinate"
                                  [value]="getProgressPercentage('calories')"
                                  class="calories-bar">
                </mat-progress-bar>
                <div class="progress-footer">
                  <span>{{getProgressPercentage('calories')}}% of goal</span>
                  <span>{{getRemainingCalories()}} remaining</span>
                </div>
              </div>

              <!-- Protein -->
              <div class="progress-item">
                <div class="progress-header">
                  <h3>Protein</h3>
                  <span class="progress-values">
                    {{dashboardData.today_nutrition?.protein_consumed || 0}}g /
                    {{dashboardData.active_goal?.target_protein || 0}}g
                  </span>
                </div>
                <mat-progress-bar mode="determinate"
                                  [value]="getProgressPercentage('protein')"
                                  color="accent"
                                  class="protein-bar">
                </mat-progress-bar>
                <div class="progress-footer">
                  <span>{{getProgressPercentage('protein')}}% of goal</span>
                </div>
              </div>

              <!-- Carbs -->
              <div class="progress-item">
                <div class="progress-header">
                  <h3>Carbohydrates</h3>
                  <span class="progress-values">
                    {{dashboardData.today_nutrition?.carbs_consumed || 0}}g /
                    {{dashboardData.active_goal?.target_carbs || 0}}g
                  </span>
                </div>
                <mat-progress-bar mode="determinate"
                                  [value]="getProgressPercentage('carbs')"
                                  color="warn"
                                  class="carbs-bar">
                </mat-progress-bar>
                <div class="progress-footer">
                  <span>{{getProgressPercentage('carbs')}}% of goal</span>
                </div>
              </div>

              <!-- Fat -->
              <div class="progress-item">
                <div class="progress-header">
                  <h3>Fat</h3>
                  <span class="progress-values">
                    {{dashboardData.today_nutrition?.fat_consumed || 0}}g /
                    {{dashboardData.active_goal?.target_fat || 0}}g
                  </span>
                </div>
                <mat-progress-bar mode="determinate"
                                  [value]="getProgressPercentage('fat')"
                                  class="fat-bar">
                </mat-progress-bar>
                <div class="progress-footer">
                  <span>{{getProgressPercentage('fat')}}% of goal</span>
                </div>
              </div>
            </div>

            <!-- Quick Actions -->
            <div class="quick-actions">
              <button mat-raised-button color="primary" (click)="logWater()">
                <mat-icon>local_drink</mat-icon>
                Log Water (250ml)
              </button>
              <button mat-raised-button (click)="quickLogMeal()">
                <mat-icon>restaurant</mat-icon>
                Quick Log Meal
              </button>
              <div class="water-progress">
                <mat-icon>local_drink</mat-icon>
                <span>Water: {{dashboardData.today_nutrition?.water_intake || 0}}L / 2.5L</span>
                <mat-progress-bar mode="determinate"
                                  [value]="getWaterProgress()"
                                  class="water-bar">
                </mat-progress-bar>
              </div>
            </div>
          </mat-card-content>
        </mat-card>
      </div>

      <!-- Charts Section -->
      <div class="charts-section">
        <!-- Macronutrient Breakdown -->
        <mat-card class="chart-card">
          <mat-card-header>
            <mat-card-title>Today's Macronutrient Breakdown</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="chart-container">
              <canvas baseChart
                      [data]="macroChartData"
                      [type]="macroChartType"
                      [options]="macroChartOptions">
              </canvas>
            </div>
          </mat-card-content>
        </mat-card>

        <!-- Weekly Progress -->
        <mat-card class="chart-card">
          <mat-card-header>
            <mat-card-title>Weekly Calorie Trend</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="chart-container">
              <canvas baseChart
                      [data]="weeklyChartData"
                      [type]="weeklyChartType"
                      [options]="weeklyChartOptions">
              </canvas>
            </div>
          </mat-card-content>
        </mat-card>
      </div>

      <!-- Recent Meals -->
      <div class="recent-meals">
        <mat-card>
          <mat-card-header>
            <mat-card-title>Recent Meals</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="meals-list">
              <div class="meal-item" *ngFor="let meal of dashboardData?.recent_meals">
                <div class="meal-time">
                  <mat-icon>schedule</mat-icon>
                  <span>{{meal.logged_at | date:'MMM d, h:mm a'}}</span>
                </div>
                <div class="meal-details">
                  <h4>{{meal.recipe_details?.title}}</h4>
                  <p>{{meal.meal_type | titlecase}} • {{meal.servings}} serving(s)</p>
                  <div class="meal-nutrition">
                    <span class="calories">{{meal.calories}} cal</span>
                    <span *ngIf="meal.notes" class="notes">{{meal.notes}}</span>
                  </div>
                </div>
                <button mat-icon-button color="warn" (click)="removeMeal(meal)">
                  <mat-icon>delete</mat-icon>
                </button>
              </div>

              <div class="empty-meals" *ngIf="!dashboardData?.recent_meals?.length">
                <mat-icon>restaurant</mat-icon>
                <p>No meals logged today</p>
                <button mat-button color="primary" (click)="quickLogMeal()">
                  Log Your First Meal
                </button>
              </div>
            </div>
          </mat-card-content>
        </mat-card>
      </div>

      <!-- Nutrition Goals -->
      <div class="nutrition-goals" *ngIf="dashboardData?.active_goal">
        <mat-card>
          <mat-card-header>
            <mat-card-title>Nutrition Goals</mat-card-title>
            <mat-card-subtitle>{{dashboardData.active_goal.goal_type | titlecase}} Plan</mat-card-subtitle>
          </mat-card-header>
          <mat-card-content>
            <div class="goals-grid">
              <div class="goal-item">
                <h4>Daily Calories</h4>
                <span class="goal-value">{{dashboardData.active_goal.target_calories}}</span>
              </div>
              <div class="goal-item">
                <h4>Protein</h4>
                <span class="goal-value">{{dashboardData.active_goal.target_protein}}g</span>
              </div>
              <div class="goal-item">
                <h4>Carbohydrates</h4>
                <span class="goal-value">{{dashboardData.active_goal.target_carbs}}g</span>
              </div>
              <div class="goal-item">
                <h4>Fat</h4>
                <span class="goal-value">{{dashboardData.active_goal.target_fat}}g</span>
              </div>
              <div class="goal-item">
                <h4>Fiber</h4>
                <span class="goal-value">{{dashboardData.active_goal.target_fiber}}g</span>
              </div>
              <div class="goal-item">
                <h4>Sodium</h4>
                <span class="goal-value">{{dashboardData.active_goal.target_sodium}}mg</span>
              </div>
            </div>
          </mat-card-content>
          <mat-card-actions>
            <button mat-button (click)="editGoals()">
              <mat-icon>edit</mat-icon>
              Edit Goals
            </button>
            <button mat-button (click)="autoCalculateGoals()">
              <mat-icon>auto_fix_high</mat-icon>
              Recalculate
            </button>
          </mat-card-actions>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .nutrition-container {
      padding: 24px;
      max-width: 1200px;
      margin: 0 auto;
    }
    .nutrition-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
    }
    .header-actions {
      display: flex;
      gap: 12px;
    }
    .today-progress {
      margin-bottom: 32px;
    }
    .progress-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 24px;
      margin-bottom: 24px;
    }
    .progress-item {
      padding: 16px;
      border-radius: 8px;
      background: #f8f9fa;
    }
    .progress-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }
    .progress-header h3 {
      margin: 0;
      font-size: 16px;
      color: #333;
    }
    .progress-values {
      font-weight: 500;
      color: #666;
    }
    .progress-footer {
      display: flex;
      justify-content: space-between;
      margin-top: 8px;
      font-size: 12px;
      color: #666;
    }
    .quick-actions {
      display: flex;
      gap: 16px;
      align-items: center;
      flex-wrap: wrap;
    }
    .water-progress {
      display: flex;
      align-items: center;
      gap: 8px;
      flex: 1;
      min-width: 200px;
    }
    .water-progress mat-progress-bar {
      flex: 1;
    }
    .charts-section {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 24px;
      margin-bottom: 32px;
    }
    .chart-card {
      height: 400px;
    }
    .chart-container {
      height: 300px;
      position: relative;
    }
    .recent-meals {
      margin-bottom: 32px;
    }
    .meals-list {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    .meal-item {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 12px;
      border-radius: 8px;
      background: #f8f9fa;
    }
    .meal-time {
      display: flex;
      align-items: center;
      gap: 8px;
      min-width: 150px;
      font-size: 14px;
      color: #666;
    }
    .meal-time mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
    }
    .meal-details {
      flex: 1;
    }
    .meal-details h4 {
      margin: 0 0 4px 0;
      font-size: 16px;
    }
    .meal-details p {
      margin: 0 0 8px 0;
      font-size: 14px;
      color: #666;
    }
    .meal-nutrition {
      display: flex;
      gap: 16px;
    }
    .calories {
      font-weight: 500;
      color: #3f51b5;
    }
    .notes {
      font-style: italic;
      color: #999;
    }
    .empty-meals {
      text-align: center;
      padding: 32px;
      color: #666;
    }
    .empty-meals mat-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
      margin-bottom: 16px;
    }
    .goals-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 24px;
    }
    .goal-item {
      text-align: center;
      padding: 16px;
      border-radius: 8px;
      background: #f0f8ff;
    }
    .goal-item h4 {
      margin: 0 0 8px 0;
      font-size: 14px;
      color: #666;
    }
    .goal-value {
      font-size: 20px;
      font-weight: 600;
      color: #3f51b5;
    }
    .calories-bar .mat-progress-bar-fill::after {
      background-color: #4caf50;
    }
    .protein-bar .mat-progress-bar-fill::after {
      background-color: #ff9800;
    }
    .carbs-bar .mat-progress-bar-fill::after {
      background-color: #2196f3;
    }
    .fat-bar .mat-progress-bar-fill::after {
      background-color: #9c27b0;
    }
    .water-bar .mat-progress-bar-fill::after {
      background-color: #00bcd4;
    }
  `]
})
export class NutritionDashboardComponent implements OnInit {
  dashboardData: any = null;
  isLoading = false;

  // Chart configurations
  macroChartType: ChartType = 'doughnut';
  macroChartData: ChartData<'doughnut'> = {
    labels: ['Protein', 'Carbs', 'Fat'],
    datasets: [{
      data: [30, 45, 25],
      backgroundColor: ['#ff9800', '#2196f3', '#9c27b0'],
      borderWidth: 0
    }]
  };
  macroChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom'
      }
    }
  };

  weeklyChartType: ChartType = 'line';
  weeklyChartData: ChartData<'line'> = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [{
      label: 'Calories Consumed',
      data: [1800, 2100, 1950, 2200, 1750, 2000, 1900],
      borderColor: '#3f51b5',
      backgroundColor: 'rgba(63, 81, 181, 0.1)',
      tension: 0.4
    }, {
      label: 'Calorie Goal',
      data: [2000, 2000, 2000, 2000, 2000, 2000, 2000],
      borderColor: '#f44336',
      borderDash: [5, 5],
      backgroundColor: 'transparent'
    }]
  };
  weeklyChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom'
      }
    },
    scales: {
      y: {
        beginAtZero: true
      }
    }
  };

  constructor(
    private nutritionService: NutritionService,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.loadDashboardData();
  }

  loadDashboardData(): void {
    this.isLoading = true;
    this.nutritionService.getNutritionDashboard().subscribe({
      next: (data) => {
        this.dashboardData = data;
        this.updateCharts();
        this.isLoading = false;
      },
      error: (error) => {
        this.toastr.error('Failed to load nutrition dashboard');
        this.isLoading = false;
      }
    });
  }

  updateCharts(): void {
    if (!this.dashboardData?.today_nutrition) return;

    const nutrition = this.dashboardData.today_nutrition;

    // Update macro chart with actual data
    const proteinCals = nutrition.protein_consumed * 4;
    const carbsCals = nutrition.carbs_consumed * 4;
    const fatCals = nutrition.fat_consumed * 9;
    const totalCals = proteinCals + carbsCals + fatCals;

    if (totalCals > 0) {
      this.macroChartData.datasets[0].data = [
        Math.round((proteinCals / totalCals) * 100),
        Math.round((carbsCals / totalCals) * 100),
        Math.round((fatCals / totalCals) * 100)
      ];
    }
  }

  getCurrentDate(): string {
    return new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }

  getProgressPercentage(nutrient: string): number {
    if (!this.dashboardData?.today_nutrition || !this.dashboardData?.active_goal) {
      return 0;
    }

    const consumed = this.dashboardData.today_nutrition[`${nutrient}_consumed`] || 0;
    const target = this.dashboardData.active_goal[`target_${nutrient}`] || 1;

    return Math.min(Math.round((consumed / target) * 100), 100);
  }

  getRemainingCalories(): number {
    if (!this.dashboardData?.today_nutrition || !this.dashboardData?.active_goal) {
      return 0;
    }

    const consumed = this.dashboardData.today_nutrition.calories_consumed || 0;
    const target = this.dashboardData.active_goal.target_calories || 0;

    return Math.max(0, target - consumed);
  }

  getWaterProgress(): number {
    const waterIntake = this.dashboardData?.today_nutrition?.water_intake || 0;
    const dailyTarget = 2.5; // 2.5 liters daily target
    return Math.min(Math.round((waterIntake / dailyTarget) * 100), 100);
  }

  logWater(): void {
    this.nutritionService.logWaterIntake(0.25).subscribe({
      next: () => {
        this.loadDashboardData();
        this.toastr.success('Water intake logged (250ml)');
      },
      error: (error) => {
        this.toastr.error('Failed to log water intake');
      }
    });
  }

  quickLogMeal(): void {
    // TODO: Open dialog for quick meal logging
    this.toastr.info('Quick meal logging dialog will be implemented');
  }

  removeMeal(meal: MealLog): void {
    // TODO: Implement meal removal
    this.toastr.info('Meal removal will be implemented');
  }

  autoCalculateGoals(): void {
    this.nutritionService.autoCalculateGoals().subscribe({
      next: (response) => {
        this.loadDashboardData();
        this.toastr.success('Nutrition goals calculated based on your profile');
      },
      error: (error) => {
        this.toastr.error('Failed to calculate goals. Please update your profile.');
      }
    });
  }

  editGoals(): void {
    // TODO: Open dialog to edit nutrition goals
    this.toastr.info('Edit goals dialog will be implemented');
  }

  generateReport(): void {
    this.nutritionService.generateNutritionReport('weekly').subscribe({
      next: (report) => {
        this.toastr.success('Weekly nutrition report generated');
        // TODO: Display or download report
      },
      error: (error) => {
        this.toastr.error('Failed to generate report');
      }
    });
  }
}
