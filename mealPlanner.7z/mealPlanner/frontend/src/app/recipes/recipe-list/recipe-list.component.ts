import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MealPlanService, Recipe } from '../../core/services/meal-plan.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-recipe-list',
  template: `
    <div class="recipe-container">
      <div class="recipe-header">
        <h1>Recipe Collection</h1>
        <button mat-raised-button color="primary" (click)="createRecipe()">
          <mat-icon>add</mat-icon>
          Add Recipe
        </button>
      </div>

      <!-- Search and Filters -->
      <div class="recipe-filters">
        <mat-form-field appearance="outline" class="search-field">
          <mat-label>Search recipes</mat-label>
          <input matInput [(ngModel)]="searchQuery" (input)="filterRecipes()">
          <mat-icon matSuffix>search</mat-icon>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Meal Type</mat-label>
          <mat-select [(ngModel)]="selectedMealType" (selectionChange)="filterRecipes()">
            <mat-option value="">All</mat-option>
            <mat-option value="breakfast">Breakfast</mat-option>
            <mat-option value="lunch">Lunch</mat-option>
            <mat-option value="dinner">Dinner</mat-option>
            <mat-option value="snack">Snack</mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Difficulty</mat-label>
          <mat-select [(ngModel)]="selectedDifficulty" (selectionChange)="filterRecipes()">
            <mat-option value="">All</mat-option>
            <mat-option value="easy">Easy</mat-option>
            <mat-option value="medium">Medium</mat-option>
            <mat-option value="hard">Hard</mat-option>
          </mat-select>
        </mat-form-field>

        <mat-form-field appearance="outline">
          <mat-label>Sort By</mat-label>
          <mat-select [(ngModel)]="sortBy" (selectionChange)="sortRecipes()">
            <mat-option value="created_at">Date Added</mat-option>
            <mat-option value="rating">Rating</mat-option>
            <mat-option value="prep_time">Prep Time</mat-option>
            <mat-option value="total_calories">Calories</mat-option>
          </mat-select>
        </mat-form-field>
      </div>

      <!-- Recipe Grid -->
      <div class="recipe-grid" *ngIf="!isLoading">
        <mat-card class="recipe-card" *ngFor="let recipe of filteredRecipes">
          <div class="recipe-image-container">
            <img mat-card-image [src]="recipe.image || 'assets/default-recipe.jpg'"
                 [alt]="recipe.title" class="recipe-image">
            <button mat-icon-button class="favorite-btn"
                    [color]="recipe.is_favorite ? 'warn' : 'primary'"
                    (click)="toggleFavorite(recipe)">
              <mat-icon>{{recipe.is_favorite ? 'favorite' : 'favorite_border'}}</mat-icon>
            </button>
          </div>

          <mat-card-header>
            <mat-card-title>{{recipe.title}}</mat-card-title>
            <mat-card-subtitle>by {{recipe.created_by_name}}</mat-card-subtitle>
          </mat-card-header>

          <mat-card-content>
            <p class="recipe-description">{{recipe.description | slice:0:100}}...</p>

            <div class="recipe-meta">
              <div class="meta-item">
                <mat-icon>schedule</mat-icon>
                <span>{{recipe.total_time}}min</span>
              </div>
              <div class="meta-item">
                <mat-icon>local_fire_department</mat-icon>
                <span>{{recipe.total_calories}} cal</span>
              </div>
              <div class="meta-item">
                <mat-icon>people</mat-icon>
                <span>{{recipe.servings}} servings</span>
              </div>
            </div>

            <div class="recipe-tags">
              <mat-chip [color]="getDifficultyColor(recipe.difficulty)">
                {{recipe.difficulty}}
              </mat-chip>
              <mat-chip>{{recipe.meal_type}}</mat-chip>
              <mat-chip *ngIf="recipe.cuisine_type">{{recipe.cuisine_type}}</mat-chip>
            </div>

            <div class="recipe-rating">
              <div class="stars">
                <mat-icon *ngFor="let star of getStars(recipe.rating)"
                          [class.filled]="star">star</mat-icon>
              </div>
              <span>({{recipe.rating}}/5)</span>
            </div>
          </mat-card-content>

          <mat-card-actions>
            <button mat-button color="primary" (click)="viewRecipe(recipe.id)">
              <mat-icon>visibility</mat-icon>
              View Details
            </button>
            <button mat-button (click)="addToMealPlan(recipe)">
              <mat-icon>event</mat-icon>
              Add to Plan
            </button>
            <button mat-button [matMenuTriggerFor]="recipeMenu">
              <mat-icon>more_vert</mat-icon>
            </button>
            <mat-menu #recipeMenu="matMenu">
              <button mat-menu-item (click)="editRecipe(recipe.id)">
                <mat-icon>edit</mat-icon>
                Edit
              </button>
              <button mat-menu-item (click)="duplicateRecipe(recipe)">
                <mat-icon>content_copy</mat-icon>
                Duplicate
              </button>
              <button mat-menu-item (click)="deleteRecipe(recipe)" class="delete-action">
                <mat-icon>delete</mat-icon>
                Delete
              </button>
            </mat-menu>
          </mat-card-actions>
        </mat-card>
      </div>

      <!-- Loading State -->
      <div class="loading-container" *ngIf="isLoading">
        <mat-spinner></mat-spinner>
        <p>Loading recipes...</p>
      </div>

      <!-- Empty State -->
      <div class="empty-state" *ngIf="!isLoading && filteredRecipes.length === 0">
        <mat-icon class="empty-icon">restaurant_menu</mat-icon>
        <h3>No recipes found</h3>
        <p>Try adjusting your search criteria or add your first recipe!</p>
        <button mat-raised-button color="primary" (click)="createRecipe()">
          <mat-icon>add</mat-icon>
          Add Your First Recipe
        </button>
      </div>
    </div>
  `,
  styles: [`
    .recipe-container {
      padding: 24px;
      max-width: 1200px;
      margin: 0 auto;
    }
    .recipe-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 32px;
    }
    .recipe-filters {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1fr;
      gap: 16px;
      margin-bottom: 32px;
      align-items: end;
    }
    .search-field {
      grid-column: 1;
    }
    .recipe-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 24px;
    }
    .recipe-card {
      position: relative;
      transition: transform 0.2s, box-shadow 0.2s;
    }
    .recipe-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    }
    .recipe-image-container {
      position: relative;
    }
    .recipe-image {
      height: 200px;
      object-fit: cover;
      width: 100%;
    }
    .favorite-btn {
      position: absolute;
      top: 8px;
      right: 8px;
      background: rgba(255, 255, 255, 0.9);
    }
    .recipe-description {
      color: #666;
      line-height: 1.4;
      margin-bottom: 16px;
    }
    .recipe-meta {
      display: flex;
      justify-content: space-between;
      margin-bottom: 16px;
    }
    .meta-item {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 14px;
      color: #666;
    }
    .meta-item mat-icon {
      font-size: 18px;
      width: 18px;
      height: 18px;
    }
    .recipe-tags {
      display: flex;
      gap: 8px;
      margin-bottom: 16px;
      flex-wrap: wrap;
    }
    .recipe-rating {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 8px;
    }
    .stars {
      display: flex;
      gap: 2px;
    }
    .stars mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
      color: #ddd;
    }
    .stars mat-icon.filled {
      color: #ffc107;
    }
    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 16px;
      padding: 64px;
    }
    .empty-state {
      text-align: center;
      padding: 64px 32px;
    }
    .empty-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      color: #ccc;
      margin-bottom: 16px;
    }
    .empty-state h3 {
      margin: 0 0 8px 0;
      color: #666;
    }
    .empty-state p {
      margin: 0 0 24px 0;
      color: #999;
    }
    .delete-action {
      color: #f44336;
    }
  `]
})
export class RecipeListComponent implements OnInit {
  recipes: Recipe[] = [];
  filteredRecipes: Recipe[] = [];
  searchQuery = '';
  selectedMealType = '';
  selectedDifficulty = '';
  sortBy = 'created_at';
  isLoading = false;

  constructor(
    private mealPlanService: MealPlanService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.loadRecipes();
  }

  loadRecipes(): void {
    this.isLoading = true;
    this.mealPlanService.getRecipes().subscribe({
      next: (recipes) => {
        this.recipes = recipes;
        this.filteredRecipes = [...this.recipes];
        this.sortRecipes();
        this.isLoading = false;
      },
      error: (error) => {
        this.toastr.error('Failed to load recipes');
        this.isLoading = false;
      }
    });
  }

  filterRecipes(): void {
    this.filteredRecipes = this.recipes.filter(recipe => {
      const matchesSearch = !this.searchQuery ||
        recipe.title.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
        recipe.description.toLowerCase().includes(this.searchQuery.toLowerCase());
      const matchesMealType = !this.selectedMealType || recipe.meal_type === this.selectedMealType;
      const matchesDifficulty = !this.selectedDifficulty || recipe.difficulty === this.selectedDifficulty;

      return matchesSearch && matchesMealType && matchesDifficulty;
    });
    this.sortRecipes();
  }

  sortRecipes(): void {
    this.filteredRecipes.sort((a, b) => {
      switch (this.sortBy) {
        case 'rating':
          return b.rating - a.rating;
        case 'prep_time':
          return a.prep_time - b.prep_time;
        case 'total_calories':
          return a.total_calories - b.total_calories;
        default:
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      }
    });
  }

  getDifficultyColor(difficulty: string): string {
    switch (difficulty) {
      case 'easy': return 'primary';
      case 'medium': return 'accent';
      case 'hard': return 'warn';
      default: return 'primary';
    }
  }

  getStars(rating: number): boolean[] {
    return Array(5).fill(false).map((_, index) => index < Math.floor(rating));
  }

  toggleFavorite(recipe: Recipe): void {
    this.mealPlanService.toggleFavoriteRecipe(recipe.id).subscribe({
      next: (response) => {
        recipe.is_favorite = !recipe.is_favorite;
        this.toastr.success(response.message);
      },
      error: (error) => {
        this.toastr.error('Failed to update favorite status');
      }
    });
  }

  viewRecipe(id: number): void {
    this.router.navigate(['/recipes', id]);
  }

  createRecipe(): void {
    // TODO: Navigate to recipe creation form
    this.toastr.info('Recipe creation form will be implemented');
  }

  editRecipe(id: number): void {
    // TODO: Navigate to recipe edit form
    this.toastr.info('Recipe editing will be implemented');
  }

  addToMealPlan(recipe: Recipe): void {
    // TODO: Open dialog to add to meal plan
    this.toastr.info('Add to meal plan dialog will be implemented');
  }

  duplicateRecipe(recipe: Recipe): void {
    // TODO: Implement recipe duplication
    this.toastr.info('Recipe duplication will be implemented');
  }

  deleteRecipe(recipe: Recipe): void {
    if (confirm(`Are you sure you want to delete "${recipe.title}"?`)) {
      this.mealPlanService.deleteRecipe(recipe.id).subscribe({
        next: () => {
          this.loadRecipes();
          this.toastr.success('Recipe deleted successfully');
        },
        error: (error) => {
          this.toastr.error('Failed to delete recipe');
        }
      });
    }
  }
}
