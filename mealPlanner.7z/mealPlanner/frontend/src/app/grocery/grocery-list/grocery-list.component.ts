import { Component, OnInit } from '@angular/core';
import { GroceryService, GroceryList, GroceryItem } from '../../core/services/grocery.service';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-grocery-list',
  template: `
    <div class="grocery-container">
      <div class="grocery-header">
        <h1>Grocery Lists</h1>
        <div class="header-actions">
          <button mat-raised-button color="primary" (click)="createNewList()">
            <mat-icon>add</mat-icon>
            New List
          </button>
          <button mat-raised-button color="accent" (click)="startVoiceInput()">
            <mat-icon>mic</mat-icon>
            Voice Add
          </button>
        </div>
      </div>

      <!-- Active Grocery List -->
      <div class="active-list" *ngIf="activeList">
        <mat-card>
          <mat-card-header>
            <mat-card-title>{{activeList.name}}</mat-card-title>
            <mat-card-subtitle>
              {{activeList.items?.length || 0}} items •
              {{activeList.completion_percentage}}% complete •
              ${{activeList.total_estimated_cost}} estimated
            </mat-card-subtitle>
          </mat-card-header>

          <mat-card-content>
            <!-- Progress Bar -->
            <div class="progress-section">
              <mat-progress-bar mode="determinate" [value]="activeList.completion_percentage"></mat-progress-bar>
              <div class="progress-info">
                <span>{{getPurchasedCount()}} of {{activeList.items?.length || 0}} items purchased</span>
                <span [class.over-budget]="activeList.is_over_budget">
                  ${{activeList.total_actual_cost}} / ${{activeList.total_estimated_cost}}
                </span>
              </div>
            </div>

            <!-- Quick Add Item -->
            <div class="quick-add">
              <mat-form-field appearance="outline" class="add-item-field">
                <mat-label>Add item (e.g., "2 apples" or "milk")</mat-label>
                <input matInput [(ngModel)]="newItemText" (keyup.enter)="addQuickItem()"
                       placeholder="Type item or use voice command">
                <button matSuffix mat-icon-button (click)="addQuickItem()" [disabled]="!newItemText">
                  <mat-icon>add</mat-icon>
                </button>
              </mat-form-field>
              <button mat-raised-button color="accent" (click)="toggleVoiceInput()"
                      [class.recording]="isRecording">
                <mat-icon>{{isRecording ? 'mic_off' : 'mic'}}</mat-icon>
                {{isRecording ? 'Stop' : 'Voice'}}
              </button>
            </div>

            <!-- Grocery Items by Category -->
            <div class="items-section">
              <div class="category-section" *ngFor="let category of getItemsByCategory()">
                <div class="category-header">
                  <h3>{{category.name}}</h3>
                  <span class="item-count">{{category.items.length}} items</span>
                </div>

                <div class="item-list">
                  <div class="grocery-item" *ngFor="let item of category.items"
                       [class.purchased]="item.is_purchased">
                    <mat-checkbox [(ngModel)]="item.is_purchased"
                                  (change)="toggleItemPurchased(item)">
                    </mat-checkbox>

                    <div class="item-details">
                      <div class="item-main">
                        <span class="item-name">{{item.quantity}} {{item.unit}} {{item.name}}</span>
                        <mat-chip *ngIf="item.brand" class="brand-chip">{{item.brand}}</mat-chip>
                        <mat-chip *ngIf="item.added_by_voice" class="voice-chip" color="accent">
                          <mat-icon>mic</mat-icon>
                          Voice
                        </mat-chip>
                      </div>

                      <div class="item-meta">
                        <span class="price">Est: ${{item.estimated_price}}</span>
                        <span class="priority" [class]="'priority-' + item.priority">{{item.priority}}</span>
                        <span *ngIf="item.notes" class="notes">{{item.notes}}</span>
                      </div>
                    </div>

                    <div class="item-actions">
                      <button mat-icon-button [matMenuTriggerFor]="itemMenu">
                        <mat-icon>more_vert</mat-icon>
                      </button>
                      <mat-menu #itemMenu="matMenu">
                        <button mat-menu-item (click)="editItem(item)">
                          <mat-icon>edit</mat-icon>
                          Edit
                        </button>
                        <button mat-menu-item (click)="setActualPrice(item)">
                          <mat-icon>receipt</mat-icon>
                          Set Price
                        </button>
                        <button mat-menu-item (click)="deleteItem(item)" class="delete-action">
                          <mat-icon>delete</mat-icon>
                          Delete
                        </button>
                      </mat-menu>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Voice Recording Indicator -->
            <div class="voice-recording" *ngIf="isRecording">
              <mat-card class="recording-card">
                <div class="recording-content">
                  <mat-icon class="recording-icon">mic</mat-icon>
                  <div>
                    <h4>Listening...</h4>
                    <p>Say something like "Add 2 pounds of chicken breast"</p>
                  </div>
                  <button mat-icon-button (click)="stopVoiceInput()">
                    <mat-icon>close</mat-icon>
                  </button>
                </div>
              </mat-card>
            </div>
          </mat-card-content>

          <mat-card-actions>
            <button mat-button (click)="shareList()">
              <mat-icon>share</mat-icon>
              Share List
            </button>
            <button mat-button (click)="exportList()">
              <mat-icon>download</mat-icon>
              Export
            </button>
            <button mat-button color="warn" (click)="clearPurchased()">
              <mat-icon>clear_all</mat-icon>
              Clear Purchased
            </button>
          </mat-card-actions>
        </mat-card>
      </div>

      <!-- All Grocery Lists -->
      <div class="all-lists">
        <h2>All Lists</h2>
        <div class="lists-grid">
          <mat-card class="list-card" *ngFor="let list of groceryLists"
                    [class.active]="list.id === activeList?.id"
                    (click)="selectList(list)">
            <mat-card-header>
              <mat-card-title>{{list.name}}</mat-card-title>
              <mat-card-subtitle>
                {{list.items?.length || 0}} items • {{list.status}}
              </mat-card-subtitle>
            </mat-card-header>

            <mat-card-content>
              <div class="list-summary">
                <div class="summary-item">
                  <mat-icon>shopping_cart</mat-icon>
                  <span>{{list.completion_percentage}}% complete</span>
                </div>
                <div class="summary-item">
                  <mat-icon>attach_money</mat-icon>
                  <span>${{list.total_estimated_cost}}</span>
                </div>
                <div class="summary-item" *ngIf="list.due_date">
                  <mat-icon>event</mat-icon>
                  <span>{{list.due_date | date:'MMM d'}}</span>
                </div>
              </div>

              <mat-progress-bar mode="determinate" [value]="list.completion_percentage"></mat-progress-bar>
            </mat-card-content>

            <mat-card-actions>
              <button mat-button (click)="editList(list); $event.stopPropagation()">Edit</button>
              <button mat-button color="warn" (click)="deleteList(list); $event.stopPropagation()">Delete</button>
            </mat-card-actions>
          </mat-card>
        </div>
      </div>

      <!-- Budget Overview -->
      <div class="budget-section">
        <mat-card>
          <mat-card-header>
            <mat-card-title>Budget Overview</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="budget-stats" *ngIf="budgetOverview">
              <div class="budget-stat">
                <h4>${{budgetOverview.total_monthly_budget}}</h4>
                <p>Monthly Budget</p>
              </div>
              <div class="budget-stat">
                <h4>${{getTotalSpent()}}</h4>
                <p>Spent This Month</p>
              </div>
              <div class="budget-stat">
                <h4>${{getRemainingBudget()}}</h4>
                <p>Remaining</p>
              </div>
            </div>
          </mat-card-content>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .grocery-container {
      padding: 24px;
      max-width: 1200px;
      margin: 0 auto;
    }
    .grocery-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
    }
    .header-actions {
      display: flex;
      gap: 12px;
    }
    .active-list {
      margin-bottom: 32px;
    }
    .progress-section {
      margin-bottom: 24px;
    }
    .progress-info {
      display: flex;
      justify-content: space-between;
      margin-top: 8px;
      font-size: 14px;
      color: #666;
    }
    .over-budget {
      color: #f44336;
      font-weight: 500;
    }
    .quick-add {
      display: flex;
      gap: 12px;
      margin-bottom: 24px;
      align-items: end;
    }
    .add-item-field {
      flex: 1;
    }
    .recording {
      background: #f44336 !important;
      color: white !important;
    }
    .items-section {
      margin-bottom: 24px;
    }
    .category-section {
      margin-bottom: 24px;
    }
    .category-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
      padding-bottom: 8px;
      border-bottom: 1px solid #eee;
    }
    .category-header h3 {
      margin: 0;
      color: #3f51b5;
    }
    .item-count {
      font-size: 14px;
      color: #666;
    }
    .item-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .grocery-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px;
      border-radius: 8px;
      background: #f8f9fa;
      transition: all 0.2s;
    }
    .grocery-item:hover {
      background: #e9ecef;
    }
    .grocery-item.purchased {
      opacity: 0.6;
      background: #e8f5e8;
    }
    .grocery-item.purchased .item-name {
      text-decoration: line-through;
    }
    .item-details {
      flex: 1;
    }
    .item-main {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 4px;
    }
    .item-name {
      font-weight: 500;
    }
    .brand-chip {
      font-size: 12px;
      height: 20px;
    }
    .voice-chip {
      font-size: 11px;
      height: 20px;
    }
    .voice-chip mat-icon {
      font-size: 14px;
      width: 14px;
      height: 14px;
    }
    .item-meta {
      display: flex;
      gap: 16px;
      font-size: 12px;
      color: #666;
    }
    .priority-high {
      color: #f44336;
      font-weight: 500;
    }
    .priority-urgent {
      color: #d32f2f;
      font-weight: 600;
    }
    .voice-recording {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 1000;
    }
    .recording-card {
      background: #3f51b5;
      color: white;
      min-width: 300px;
    }
    .recording-content {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 16px;
    }
    .recording-icon {
      font-size: 32px;
      width: 32px;
      height: 32px;
      color: #f44336;
      animation: pulse 1s infinite;
    }
    @keyframes pulse {
      0% { opacity: 1; }
      50% { opacity: 0.5; }
      100% { opacity: 1; }
    }
    .recording-content h4 {
      margin: 0;
    }
    .recording-content p {
      margin: 4px 0 0 0;
      font-size: 12px;
      opacity: 0.9;
    }
    .lists-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 16px;
      margin-bottom: 32px;
    }
    .list-card {
      cursor: pointer;
      transition: all 0.2s;
    }
    .list-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    .list-card.active {
      border: 2px solid #3f51b5;
    }
    .list-summary {
      display: flex;
      flex-direction: column;
      gap: 8px;
      margin-bottom: 12px;
    }
    .summary-item {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
    }
    .summary-item mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
      color: #666;
    }
    .budget-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
      gap: 24px;
      text-align: center;
    }
    .budget-stat h4 {
      margin: 0;
      font-size: 24px;
      color: #3f51b5;
    }
    .budget-stat p {
      margin: 4px 0 0 0;
      color: #666;
    }
    .delete-action {
      color: #f44336;
    }
  `]
})
export class GroceryListComponent implements OnInit {
  groceryLists: GroceryList[] = [];
  activeList: GroceryList | null = null;
  budgetOverview: any = null;
  newItemText = '';
  isRecording = false;
  isLoading = false;

  constructor(
    private groceryService: GroceryService,
    private toastr: ToastrService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.loadGroceryLists();
    this.loadBudgetOverview();
  }

  loadGroceryLists(): void {
    this.isLoading = true;
    this.groceryService.getGroceryLists().subscribe({
      next: (lists) => {
        this.groceryLists = lists;
        // Set the first active list as default
        this.activeList = lists.find(list => list.status === 'active') || lists[0] || null;
        this.isLoading = false;
      },
      error: (error) => {
        this.toastr.error('Failed to load grocery lists');
        this.isLoading = false;
      }
    });
  }

  loadBudgetOverview(): void {
    this.groceryService.getBudgetOverview().subscribe({
      next: (overview) => {
        this.budgetOverview = overview;
      },
      error: (error) => {
        console.error('Failed to load budget overview', error);
      }
    });
  }

  selectList(list: GroceryList): void {
    this.activeList = list;
  }

  addQuickItem(): void {
    if (!this.newItemText.trim() || !this.activeList) return;

    this.groceryService.addVoiceGroceryItem(this.activeList.id, this.newItemText).subscribe({
      next: (response) => {
        this.newItemText = '';
        this.loadGroceryLists(); // Refresh lists
        this.toastr.success(response.message);
      },
      error: (error) => {
        this.toastr.error('Failed to add item');
      }
    });
  }

  toggleVoiceInput(): void {
    if (this.isRecording) {
      this.stopVoiceInput();
    } else {
      this.startVoiceInput();
    }
  }

  startVoiceInput(): void {
    if (!this.activeList) {
      this.toastr.warning('Please select a grocery list first');
      return;
    }

    this.isRecording = true;

    // TODO: Implement actual voice recognition
    // For now, simulate voice input
    setTimeout(() => {
      this.simulateVoiceInput();
    }, 3000);
  }

  stopVoiceInput(): void {
    this.isRecording = false;
  }

  simulateVoiceInput(): void {
    // Simulate voice recognition result
    const voiceInputs = [
      'Add 2 pounds of chicken breast',
      'Buy organic apples',
      'Need milk and eggs',
      '1 loaf of whole wheat bread'
    ];

    const randomInput = voiceInputs[Math.floor(Math.random() * voiceInputs.length)];
    this.newItemText = randomInput;
    this.isRecording = false;
    this.toastr.info(`Voice recognized: "${randomInput}"`);
  }

  toggleItemPurchased(item: GroceryItem): void {
    if (item.is_purchased) {
      this.groceryService.markItemPurchased(item.id).subscribe({
        next: () => {
          this.loadGroceryLists(); // Refresh to update totals
          this.toastr.success(`Marked ${item.name} as purchased`);
        },
        error: (error) => {
          item.is_purchased = false; // Revert on error
          this.toastr.error('Failed to update item status');
        }
      });
    } else {
      // TODO: Implement un-marking as purchased
      this.toastr.info('Un-marking items not yet implemented');
      item.is_purchased = true; // Revert for now
    }
  }

  getItemsByCategory(): any[] {
    if (!this.activeList?.items) return [];

    const categories = new Map();

    this.activeList.items.forEach(item => {
      const categoryName = item.category_name || 'Uncategorized';
      if (!categories.has(categoryName)) {
        categories.set(categoryName, {
          name: categoryName,
          items: []
        });
      }
      categories.get(categoryName).items.push(item);
    });

    return Array.from(categories.values());
  }

  getPurchasedCount(): number {
    return this.activeList?.items?.filter(item => item.is_purchased).length || 0;
  }

  getTotalSpent(): number {
    return this.budgetOverview?.recent_spending?.reduce((total: number, spending: any) =>
      total + spending.amount, 0) || 0;
  }

  getRemainingBudget(): number {
    const totalBudget = this.budgetOverview?.total_monthly_budget || 0;
    const totalSpent = this.getTotalSpent();
    return Math.max(0, totalBudget - totalSpent);
  }

  createNewList(): void {
    // TODO: Open dialog to create new list
    this.toastr.info('Create new list dialog will be implemented');
  }

  editList(list: GroceryList): void {
    // TODO: Open dialog to edit list
    this.toastr.info('Edit list dialog will be implemented');
  }

  deleteList(list: GroceryList): void {
    if (confirm(`Are you sure you want to delete "${list.name}"?`)) {
      this.groceryService.deleteGroceryList(list.id).subscribe({
        next: () => {
          this.loadGroceryLists();
          this.toastr.success('List deleted successfully');
        },
        error: (error) => {
          this.toastr.error('Failed to delete list');
        }
      });
    }
  }

  editItem(item: GroceryItem): void {
    // TODO: Open dialog to edit item
    this.toastr.info('Edit item dialog will be implemented');
  }

  setActualPrice(item: GroceryItem): void {
    // TODO: Open dialog to set actual price
    this.toastr.info('Set actual price dialog will be implemented');
  }

  deleteItem(item: GroceryItem): void {
    this.groceryService.deleteGroceryItem(item.id).subscribe({
      next: () => {
        this.loadGroceryLists();
        this.toastr.success('Item deleted');
      },
      error: (error) => {
        this.toastr.error('Failed to delete item');
      }
    });
  }

  shareList(): void {
    // TODO: Implement list sharing
    this.toastr.info('List sharing will be implemented');
  }

  exportList(): void {
    // TODO: Implement list export
    this.toastr.info('List export will be implemented');
  }

  clearPurchased(): void {
    if (confirm('Remove all purchased items from the list?')) {
      // TODO: Implement clearing purchased items
      this.toastr.info('Clear purchased items will be implemented');
    }
  }
}
