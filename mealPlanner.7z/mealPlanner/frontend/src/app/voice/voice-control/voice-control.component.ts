import { Component, OnInit, OnDestroy } from '@angular/core';
import { VoiceService, VoiceCommand, VoiceSession } from '../../core/services/voice.service';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-voice-control',
  template: `
    <div class="voice-container">
      <div class="voice-header">
        <h1>Voice Control Center</h1>
        <div class="header-actions">
          <button mat-raised-button
                  [color]="isListening ? 'warn' : 'primary'"
                  (click)="toggleVoiceListening()"
                  [disabled]="isProcessing">
            <mat-icon>{{isListening ? 'mic_off' : 'mic'}}</mat-icon>
            {{isListening ? 'Stop Listening' : 'Start Voice Control'}}
          </button>
          <button mat-raised-button color="accent" (click)="viewSettings()">
            <mat-icon>settings</mat-icon>
            Voice Settings
          </button>
        </div>
      </div>

      <!-- Voice Status -->
      <div class="voice-status">
        <mat-card [class.listening]="isListening" [class.processing]="isProcessing">
          <mat-card-content>
            <div class="status-content">
              <div class="status-icon">
                <mat-icon class="voice-icon" [class.pulse]="isListening">
                  {{getStatusIcon()}}
                </mat-icon>
              </div>
              <div class="status-text">
                <h3>{{getStatusTitle()}}</h3>
                <p>{{getStatusDescription()}}</p>
                <div class="transcription" *ngIf="currentTranscription">
                  <strong>Heard:</strong> "{{currentTranscription}}"
                </div>
              </div>
            </div>

            <!-- Voice Commands Help -->
            <div class="voice-help" *ngIf="!isListening && !isProcessing">
              <h4>Try saying:</h4>
              <div class="command-examples">
                <mat-chip-listbox>
                  <mat-chip-option *ngFor="let example of commandExamples">
                    "{{example}}"
                  </mat-chip-option>
                </mat-chip-listbox>
              </div>
            </div>
          </mat-card-content>
        </mat-card>
      </div>

      <!-- Quick Text Input -->
      <div class="text-input-section">
        <mat-card>
          <mat-card-header>
            <mat-card-title>Text Command Input</mat-card-title>
            <mat-card-subtitle>Type commands instead of speaking</mat-card-subtitle>
          </mat-card-header>
          <mat-card-content>
            <div class="text-input-row">
              <mat-form-field appearance="outline" class="command-input">
                <mat-label>Enter voice command</mat-label>
                <input matInput
                       [(ngModel)]="textCommand"
                       (keyup.enter)="processTextCommand()"
                       placeholder="e.g., 'Add 2 apples to grocery list' or 'Search for pasta recipes'">
              </mat-form-field>
              <button mat-raised-button
                      color="primary"
                      (click)="processTextCommand()"
                      [disabled]="!textCommand || isProcessing">
                <mat-icon>send</mat-icon>
                Process
              </button>
            </div>
          </mat-card-content>
        </mat-card>
      </div>

      <!-- Recent Commands -->
      <div class="recent-commands">
        <mat-card>
          <mat-card-header>
            <mat-card-title>Recent Voice Commands</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="commands-list">
              <div class="command-item"
                   *ngFor="let command of recentCommands"
                   [class]="'status-' + command.status">

                <div class="command-icon">
                  <mat-icon [color]="getCommandStatusColor(command.status)">
                    {{getCommandIcon(command.status)}}
                  </mat-icon>
                </div>

                <div class="command-details">
                  <div class="command-text">
                    <strong>"{{command.transcribed_text}}"</strong>
                  </div>
                  <div class="command-meta">
                    <span class="command-type">{{command.command_type | titlecase}}</span>
                    <span class="command-time">{{command.created_at | date:'MMM d, h:mm a'}}</span>
                    <span class="command-confidence" *ngIf="command.confidence_score">
                      {{command.confidence_score * 100 | number:'1.0-0'}}% confidence
                    </span>
                  </div>
                  <div class="command-response" *ngIf="command.response_text">
                    <mat-icon>reply</mat-icon>
                    <span>{{command.response_text}}</span>
                  </div>
                </div>

                <div class="command-actions">
                  <button mat-icon-button [matMenuTriggerFor]="commandMenu">
                    <mat-icon>more_vert</mat-icon>
                  </button>
                  <mat-menu #commandMenu="matMenu">
                    <button mat-menu-item (click)="repeatCommand(command)">
                      <mat-icon>replay</mat-icon>
                      Repeat Command
                    </button>
                    <button mat-menu-item (click)="viewCommandDetails(command)">
                      <mat-icon>info</mat-icon>
                      View Details
                    </button>
                  </mat-menu>
                </div>
              </div>

              <div class="empty-commands" *ngIf="recentCommands.length === 0">
                <mat-icon>mic_none</mat-icon>
                <p>No voice commands yet</p>
                <p>Start by saying a command or typing one above</p>
              </div>
            </div>
          </mat-card-content>
        </mat-card>
      </div>

      <!-- Voice Analytics -->
      <div class="voice-analytics" *ngIf="voiceAnalytics">
        <mat-card>
          <mat-card-header>
            <mat-card-title>Voice Usage Analytics</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="analytics-grid">
              <div class="analytics-item">
                <h4>{{voiceAnalytics.total_commands}}</h4>
                <p>Total Commands</p>
              </div>
              <div class="analytics-item">
                <h4>{{voiceAnalytics.success_rate | number:'1.0-0'}}%</h4>
                <p>Success Rate</p>
              </div>
              <div class="analytics-item">
                <h4>{{voiceAnalytics.successful_commands}}</h4>
                <p>Successful</p>
              </div>
              <div class="analytics-item">
                <h4>{{getAverageProcessingTime()}}s</h4>
                <p>Avg Processing</p>
              </div>
            </div>

            <div class="most-used-commands" *ngIf="voiceAnalytics.most_used_commands?.length">
              <h4>Most Used Commands</h4>
              <div class="command-usage">
                <div class="usage-item" *ngFor="let usage of voiceAnalytics.most_used_commands">
                  <span class="command-name">{{usage.command_type | titlecase}}</span>
                  <span class="usage-count">{{usage.count}} times</span>
                  <mat-progress-bar mode="determinate"
                                    [value]="getUsagePercentage(usage.count)">
                  </mat-progress-bar>
                </div>
              </div>
            </div>
          </mat-card-content>
        </mat-card>
      </div>

      <!-- Voice Session Info -->
      <div class="session-info" *ngIf="currentSession">
        <mat-card class="session-card">
          <mat-card-content>
            <div class="session-details">
              <mat-icon>record_voice_over</mat-icon>
              <div>
                <strong>Active Voice Session</strong>
                <p>{{currentSession.commands_count}} commands processed</p>
              </div>
              <button mat-button color="warn" (click)="endCurrentSession()">
                End Session
              </button>
            </div>
          </mat-card-content>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .voice-container {
      padding: 24px;
      max-width: 1000px;
      margin: 0 auto;
    }
    .voice-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
    }
    .header-actions {
      display: flex;
      gap: 12px;
    }
    .voice-status {
      margin-bottom: 24px;
    }
    .voice-status mat-card {
      transition: all 0.3s;
    }
    .voice-status mat-card.listening {
      background: linear-gradient(135deg, #e8f5e8 0%, #c8e6c9 100%);
      border: 2px solid #4caf50;
    }
    .voice-status mat-card.processing {
      background: linear-gradient(135deg, #fff3e0 0%, #ffcc02 100%);
      border: 2px solid #ff9800;
    }
    .status-content {
      display: flex;
      align-items: center;
      gap: 24px;
      margin-bottom: 16px;
    }
    .status-icon {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .voice-icon {
      font-size: 48px;
      width: 48px;
      height: 48px;
      color: #3f51b5;
    }
    .voice-icon.pulse {
      animation: pulse 1.5s infinite;
      color: #4caf50;
    }
    @keyframes pulse {
      0% { transform: scale(1); opacity: 1; }
      50% { transform: scale(1.1); opacity: 0.7; }
      100% { transform: scale(1); opacity: 1; }
    }
    .status-text h3 {
      margin: 0 0 8px 0;
      color: #333;
    }
    .status-text p {
      margin: 0;
      color: #666;
    }
    .transcription {
      margin-top: 12px;
      padding: 8px 12px;
      background: rgba(63, 81, 181, 0.1);
      border-radius: 4px;
      font-style: italic;
    }
    .voice-help h4 {
      margin: 16px 0 8px 0;
      color: #333;
    }
    .command-examples {
      margin-top: 8px;
    }
    .text-input-section {
      margin-bottom: 24px;
    }
    .text-input-row {
      display: flex;
      gap: 12px;
      align-items: end;
    }
    .command-input {
      flex: 1;
    }
    .recent-commands {
      margin-bottom: 24px;
    }
    .commands-list {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    .command-item {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 16px;
      border-radius: 8px;
      background: #f8f9fa;
      transition: all 0.2s;
    }
    .command-item:hover {
      background: #e9ecef;
    }
    .command-item.status-completed {
      border-left: 4px solid #4caf50;
    }
    .command-item.status-failed {
      border-left: 4px solid #f44336;
    }
    .command-item.status-processing {
      border-left: 4px solid #ff9800;
    }
    .command-icon {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .command-details {
      flex: 1;
    }
    .command-text {
      margin-bottom: 8px;
      font-size: 16px;
    }
    .command-meta {
      display: flex;
      gap: 16px;
      font-size: 12px;
      color: #666;
      margin-bottom: 8px;
    }
    .command-response {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
      color: #333;
      background: rgba(63, 81, 181, 0.05);
      padding: 8px;
      border-radius: 4px;
    }
    .command-response mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
      color: #666;
    }
    .empty-commands {
      text-align: center;
      padding: 48px;
      color: #666;
    }
    .empty-commands mat-icon {
      font-size: 64px;
      width: 64px;
      height: 64px;
      margin-bottom: 16px;
      color: #ccc;
    }
    .voice-analytics {
      margin-bottom: 24px;
    }
    .analytics-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
      gap: 24px;
      margin-bottom: 24px;
    }
    .analytics-item {
      text-align: center;
      padding: 16px;
      border-radius: 8px;
      background: #f0f8ff;
    }
    .analytics-item h4 {
      margin: 0 0 8px 0;
      font-size: 24px;
      color: #3f51b5;
    }
    .analytics-item p {
      margin: 0;
      color: #666;
      font-size: 14px;
    }
    .most-used-commands h4 {
      margin: 0 0 16px 0;
      color: #333;
    }
    .command-usage {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    .usage-item {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .command-name {
      min-width: 120px;
      font-weight: 500;
    }
    .usage-count {
      min-width: 80px;
      font-size: 14px;
      color: #666;
    }
    .usage-item mat-progress-bar {
      flex: 1;
      height: 6px;
    }
    .session-info {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 1000;
    }
    .session-card {
      background: #3f51b5;
      color: white;
      min-width: 300px;
    }
    .session-details {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .session-details mat-icon {
      font-size: 24px;
      width: 24px;
      height: 24px;
    }
    .session-details div {
      flex: 1;
    }
    .session-details strong {
      display: block;
      margin-bottom: 4px;
    }
    .session-details p {
      margin: 0;
      font-size: 12px;
      opacity: 0.9;
    }
  `]
})
export class VoiceControlComponent implements OnInit, OnDestroy {
  isListening = false;
  isProcessing = false;
  currentTranscription = '';
  textCommand = '';

  recentCommands: VoiceCommand[] = [];
  voiceAnalytics: any = null;
  currentSession: VoiceSession | null = null;

  commandExamples = [
    'Add 2 pounds of chicken to grocery list',
    'Search for pasta recipes',
    'Log chicken salad for lunch',
    'Add 1 glass of water',
    'Show me today\'s nutrition',
    'Create a new meal plan'
  ];

  constructor(
    private voiceService: VoiceService,
    private toastr: ToastrService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.loadRecentCommands();
    this.loadVoiceAnalytics();
  }

  ngOnDestroy(): void {
    if (this.isListening) {
      this.stopVoiceListening();
    }
    if (this.currentSession) {
      this.endCurrentSession();
    }
  }

  loadRecentCommands(): void {
    this.voiceService.getVoiceCommands().subscribe({
      next: (commands) => {
        this.recentCommands = commands.slice(0, 10); // Show last 10 commands
      },
      error: (error) => {
        console.error('Failed to load recent commands', error);
      }
    });
  }

  loadVoiceAnalytics(): void {
    this.voiceService.getVoiceAnalytics().subscribe({
      next: (analytics) => {
        this.voiceAnalytics = analytics;
      },
      error: (error) => {
        console.error('Failed to load voice analytics', error);
      }
    });
  }

  toggleVoiceListening(): void {
    if (this.isListening) {
      this.stopVoiceListening();
    } else {
      this.startVoiceListening();
    }
  }

  startVoiceListening(): void {
    this.isListening = true;
    this.currentTranscription = '';

    // Start voice session
    this.voiceService.startVoiceSession().subscribe({
      next: (response) => {
        this.currentSession = response;
        this.toastr.success('Voice listening started');

        // Start actual speech recognition
        this.listenForSpeech();
      },
      error: (error) => {
        this.isListening = false;
        this.toastr.error('Failed to start voice session');
      }
    });
  }

  stopVoiceListening(): void {
    this.isListening = false;
    this.currentTranscription = '';
    this.toastr.info('Voice listening stopped');
  }

  listenForSpeech(): void {
    if (!this.isListening) return;

    // Simulate speech recognition - in real implementation, this would use Web Speech API
    // or connect to the backend speech recognition service
    this.simulateSpeechRecognition();
  }

  simulateSpeechRecognition(): void {
    // Simulate voice recognition with random examples
    setTimeout(() => {
      if (!this.isListening) return;

      const randomCommand = this.commandExamples[Math.floor(Math.random() * this.commandExamples.length)];
      this.currentTranscription = randomCommand;

      setTimeout(() => {
        if (this.isListening) {
          this.processVoiceCommand(randomCommand);
        }
      }, 1000);
    }, 2000);
  }

  processVoiceCommand(text: string): void {
    this.isProcessing = true;

    this.voiceService.processVoiceCommand(undefined, text).subscribe({
      next: (response) => {
        this.isProcessing = false;
        this.currentTranscription = '';

        this.toastr.success(response.response);
        this.loadRecentCommands();
        this.loadVoiceAnalytics();

        // Continue listening if voice control is active
        if (this.isListening) {
          setTimeout(() => this.listenForSpeech(), 1000);
        }
      },
      error: (error) => {
        this.isProcessing = false;
        this.currentTranscription = '';
        this.toastr.error('Failed to process voice command');

        if (this.isListening) {
          setTimeout(() => this.listenForSpeech(), 1000);
        }
      }
    });
  }

  processTextCommand(): void {
    if (!this.textCommand.trim()) return;

    this.isProcessing = true;
    const command = this.textCommand;
    this.textCommand = '';

    this.voiceService.processVoiceCommand(undefined, command).subscribe({
      next: (response) => {
        this.isProcessing = false;
        this.toastr.success(response.response);
        this.loadRecentCommands();
        this.loadVoiceAnalytics();
      },
      error: (error) => {
        this.isProcessing = false;
        this.toastr.error('Failed to process command');
      }
    });
  }

  getStatusIcon(): string {
    if (this.isProcessing) return 'hourglass_empty';
    if (this.isListening) return 'mic';
    return 'mic_none';
  }

  getStatusTitle(): string {
    if (this.isProcessing) return 'Processing...';
    if (this.isListening) return 'Listening for commands';
    return 'Voice control ready';
  }

  getStatusDescription(): string {
    if (this.isProcessing) return 'Understanding your command and taking action';
    if (this.isListening) return 'Say a command like "Add apples to grocery list"';
    return 'Click the microphone button to start voice control';
  }

  getCommandStatusColor(status: string): string {
    switch (status) {
      case 'completed': return 'primary';
      case 'failed': return 'warn';
      case 'processing': return 'accent';
      default: return '';
    }
  }

  getCommandIcon(status: string): string {
    switch (status) {
      case 'completed': return 'check_circle';
      case 'failed': return 'error';
      case 'processing': return 'hourglass_empty';
      default: return 'help';
    }
  }

  getAverageProcessingTime(): string {
    if (!this.voiceAnalytics?.recent_analytics?.length) return '0';

    const avgTime = this.voiceAnalytics.recent_analytics.reduce((sum: number, item: any) =>
      sum + item.average_processing_time, 0) / this.voiceAnalytics.recent_analytics.length;

    return avgTime.toFixed(1);
  }

  getUsagePercentage(count: number): number {
    if (!this.voiceAnalytics?.most_used_commands?.length) return 0;

    const maxCount = Math.max(...this.voiceAnalytics.most_used_commands.map((cmd: any) => cmd.count));
    return (count / maxCount) * 100;
  }

  repeatCommand(command: VoiceCommand): void {
    this.processVoiceCommand(command.transcribed_text);
  }

  viewCommandDetails(command: VoiceCommand): void {
    // TODO: Open dialog with detailed command information
    this.toastr.info('Command details dialog will be implemented');
  }

  endCurrentSession(): void {
    if (!this.currentSession) return;

    this.voiceService.endVoiceSession(this.currentSession.session_id).subscribe({
      next: (response) => {
        this.currentSession = null;
        this.isListening = false;
        this.toastr.success('Voice session ended');
        this.loadVoiceAnalytics();
      },
      error: (error) => {
        this.toastr.error('Failed to end voice session');
      }
    });
  }

  viewSettings(): void {
    // TODO: Open voice settings dialog
    this.toastr.info('Voice settings dialog will be implemented');
  }
}
