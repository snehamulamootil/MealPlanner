from rest_framework import serializers
from .models import VoiceCommand, SpeechPattern, VoicePreference, VoiceSession, VoiceAnalytics


class VoiceCommandSerializer(serializers.ModelSerializer):
    class Meta:
        model = VoiceCommand
        fields = ('id', 'audio_file', 'transcribed_text', 'command_type', 'parsed_intent',
                 'status', 'confidence_score', 'response_text', 'execution_result',
                 'processing_time', 'created_at', 'completed_at')
        read_only_fields = ('user', 'transcribed_text', 'parsed_intent', 'status',
                           'confidence_score', 'response_text', 'execution_result',
                           'processing_time', 'completed_at')


class VoiceCommandCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = VoiceCommand
        fields = ('audio_file', 'transcribed_text')

    def validate(self, attrs):
        if not attrs.get('audio_file') and not attrs.get('transcribed_text'):
            raise serializers.ValidationError("Either audio file or transcribed text is required")
        return attrs


class SpeechPatternSerializer(serializers.ModelSerializer):
    class Meta:
        model = SpeechPattern
        fields = '__all__'


class VoicePreferenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = VoicePreference
        fields = ('preferred_language', 'voice_activation_enabled', 'continuous_listening',
                 'confirmation_required', 'audio_feedback_enabled', 'sensitivity_level',
                 'custom_wake_word', 'noise_cancellation', 'updated_at')
        read_only_fields = ('user',)


class VoiceSessionSerializer(serializers.ModelSerializer):
    success_rate = serializers.ReadOnlyField()

    class Meta:
        model = VoiceSession
        fields = ('id', 'session_id', 'start_time', 'end_time', 'commands_count',
                 'successful_commands', 'failed_commands', 'average_confidence',
                 'total_duration', 'success_rate')


class VoiceAnalyticsSerializer(serializers.ModelSerializer):
    class Meta:
        model = VoiceAnalytics
        fields = ('date', 'total_commands', 'successful_commands', 'most_used_command',
                 'average_processing_time', 'total_session_time')


class TextToSpeechSerializer(serializers.Serializer):
    text = serializers.CharField(max_length=1000)
    language = serializers.CharField(max_length=10, required=False, default='en-US')
    voice_type = serializers.ChoiceField(
        choices=[('male', 'Male'), ('female', 'Female')],
        default='female'
    )
