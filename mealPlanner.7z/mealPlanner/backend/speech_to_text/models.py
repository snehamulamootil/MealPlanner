from django.db import models
from django.contrib.auth import get_user_model
from django.core.files.storage import default_storage
import json

User = get_user_model()


class VoiceCommand(models.Model):
    COMMAND_TYPE_CHOICES = [
        ('add_recipe', 'Add Recipe'),
        ('add_grocery_item', 'Add Grocery Item'),
        ('create_meal_plan', 'Create Meal Plan'),
        ('log_meal', 'Log Meal'),
        ('log_water', 'Log Water Intake'),
        ('search_recipe', 'Search Recipe'),
        ('get_nutrition_info', 'Get Nutrition Info'),
        ('other', 'Other'),
    ]

    STATUS_CHOICES = [
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('cancelled', 'Cancelled'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='voice_commands')
    audio_file = models.FileField(upload_to='voice_commands/', null=True, blank=True)
    transcribed_text = models.TextField(blank=True)
    command_type = models.CharField(max_length=20, choices=COMMAND_TYPE_CHOICES, default='other')
    parsed_intent = models.JSONField(default=dict)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='processing')
    confidence_score = models.FloatField(default=0.0)
    response_text = models.TextField(blank=True)
    execution_result = models.JSONField(default=dict)
    processing_time = models.FloatField(default=0.0, help_text="Processing time in seconds")
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} - {self.command_type} ({self.status})"


class SpeechPattern(models.Model):
    """Predefined speech patterns for better NLP recognition"""
    command_type = models.CharField(max_length=20, choices=VoiceCommand.COMMAND_TYPE_CHOICES)
    pattern = models.CharField(max_length=500)
    description = models.TextField()
    example_phrases = models.JSONField(default=list)
    is_active = models.BooleanField(default=True)
    priority = models.PositiveIntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['priority', 'command_type']

    def __str__(self):
        return f"{self.command_type} - {self.pattern}"


class VoicePreference(models.Model):
    """User preferences for voice commands"""
    LANGUAGE_CHOICES = [
        ('en-US', 'English (US)'),
        ('en-GB', 'English (UK)'),
        ('en-CA', 'English (Canada)'),
        ('en-AU', 'English (Australia)'),
        ('es-ES', 'Spanish (Spain)'),
        ('es-MX', 'Spanish (Mexico)'),
        ('fr-FR', 'French (France)'),
        ('de-DE', 'German (Germany)'),
        ('it-IT', 'Italian (Italy)'),
        ('pt-BR', 'Portuguese (Brazil)'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='voice_preferences')
    preferred_language = models.CharField(max_length=10, choices=LANGUAGE_CHOICES, default='en-US')
    voice_activation_enabled = models.BooleanField(default=True)
    continuous_listening = models.BooleanField(default=False)
    confirmation_required = models.BooleanField(default=True)
    audio_feedback_enabled = models.BooleanField(default=True)
    sensitivity_level = models.FloatField(default=0.7, help_text="Voice detection sensitivity (0.1-1.0)")
    custom_wake_word = models.CharField(max_length=50, blank=True)
    noise_cancellation = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username}'s voice preferences"


class VoiceSession(models.Model):
    """Track voice interaction sessions"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='voice_sessions')
    session_id = models.CharField(max_length=100, unique=True)
    start_time = models.DateTimeField(auto_now_add=True)
    end_time = models.DateTimeField(null=True, blank=True)
    commands_count = models.PositiveIntegerField(default=0)
    successful_commands = models.PositiveIntegerField(default=0)
    failed_commands = models.PositiveIntegerField(default=0)
    average_confidence = models.FloatField(default=0.0)
    total_duration = models.FloatField(default=0.0, help_text="Session duration in seconds")

    def __str__(self):
        return f"{self.user.username} - Session {self.session_id}"

    @property
    def success_rate(self):
        if self.commands_count == 0:
            return 0
        return (self.successful_commands / self.commands_count) * 100


class VoiceAnalytics(models.Model):
    """Analytics for voice command usage"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='voice_analytics')
    date = models.DateField(auto_now_add=True)
    total_commands = models.PositiveIntegerField(default=0)
    successful_commands = models.PositiveIntegerField(default=0)
    most_used_command = models.CharField(max_length=20, blank=True)
    average_processing_time = models.FloatField(default=0.0)
    total_session_time = models.FloatField(default=0.0)

    class Meta:
        unique_together = ('user', 'date')

    def __str__(self):
        return f"{self.user.username} - {self.date} analytics"
