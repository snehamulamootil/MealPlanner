from django.apps import AppConfig


class SpeechToTextConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'speech_to_text'
