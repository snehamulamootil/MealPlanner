from rest_framework import generics, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.core.files.base import ContentFile
from django.utils import timezone
import uuid
import time
from .models import VoiceCommand, VoicePreference, VoiceSession, VoiceAnalytics
from .serializers import (
    VoiceCommandSerializer, VoiceCommandCreateSerializer, VoicePreferenceSerializer,
    VoiceSessionSerializer, TextToSpeechSerializer
)
from .services import SpeechRecognitionService, NaturalLanguageProcessor, VoiceCommandExecutor


class VoiceCommandListCreateView(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return VoiceCommandCreateSerializer
        return VoiceCommandSerializer

    def get_queryset(self):
        return VoiceCommand.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def process_voice_command(request):
    """Main endpoint for processing voice commands"""
    start_time = time.time()

    # Create voice command record
    voice_command = VoiceCommand.objects.create(
        user=request.user,
        status='processing'
    )

    try:
        # Get user's voice preferences
        try:
            preferences = VoicePreference.objects.get(user=request.user)
            language = preferences.preferred_language
        except VoicePreference.DoesNotExist:
            language = 'en-US'
            # Create default preferences
            VoicePreference.objects.create(user=request.user)

        # Handle audio file or text input
        if 'audio_file' in request.FILES:
            # Process audio file
            audio_file = request.FILES['audio_file']
            voice_command.audio_file = audio_file
            voice_command.save()

            # Transcribe audio
            speech_service = SpeechRecognitionService()
            transcription_result = speech_service.transcribe_audio(
                voice_command.audio_file.path, language
            )

            if not transcription_result['success']:
                voice_command.status = 'failed'
                voice_command.response_text = transcription_result['error']
                voice_command.save()
                return Response({
                    'error': transcription_result['error'],
                    'command_id': voice_command.id
                }, status=status.HTTP_400_BAD_REQUEST)

            voice_command.transcribed_text = transcription_result['text']
            voice_command.confidence_score = transcription_result['confidence']

        elif 'text' in request.data:
            # Direct text input
            voice_command.transcribed_text = request.data['text']
            voice_command.confidence_score = 1.0

        else:
            return Response({
                'error': 'Either audio file or text is required'
            }, status=status.HTTP_400_BAD_REQUEST)

        # Parse command using NLP
        nlp_processor = NaturalLanguageProcessor()
        parsed_result = nlp_processor.parse_command(voice_command.transcribed_text)

        voice_command.parsed_intent = parsed_result
        voice_command.command_type = parsed_result['intent']
        voice_command.save()

        # Execute command
        executor = VoiceCommandExecutor(request.user)
        execution_result = executor.execute_command(voice_command)

        # Update command with results
        voice_command.execution_result = execution_result
        voice_command.response_text = execution_result['message']
        voice_command.status = 'completed' if execution_result['success'] else 'failed'
        voice_command.processing_time = time.time() - start_time
        voice_command.completed_at = timezone.now()
        voice_command.save()

        # Update analytics
        _update_voice_analytics(request.user, voice_command)

        return Response({
            'command_id': voice_command.id,
            'transcribed_text': voice_command.transcribed_text,
            'intent': parsed_result['intent'],
            'confidence': voice_command.confidence_score,
            'response': execution_result['message'],
            'success': execution_result['success'],
            'data': execution_result['data'],
            'processing_time': voice_command.processing_time
        })

    except Exception as e:
        voice_command.status = 'failed'
        voice_command.response_text = f'Processing error: {str(e)}'
        voice_command.processing_time = time.time() - start_time
        voice_command.save()

        return Response({
            'error': f'Processing error: {str(e)}',
            'command_id': voice_command.id
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def start_voice_session(request):
    """Start a new voice interaction session"""
    session_id = str(uuid.uuid4())

    session = VoiceSession.objects.create(
        user=request.user,
        session_id=session_id
    )

    return Response({
        'session_id': session.session_id,
        'message': 'Voice session started'
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def end_voice_session(request, session_id):
    """End a voice interaction session"""
    try:
        session = VoiceSession.objects.get(
            session_id=session_id, user=request.user
        )
        session.end_time = timezone.now()

        # Calculate session statistics
        commands = VoiceCommand.objects.filter(
            user=request.user,
            created_at__gte=session.start_time,
            created_at__lte=session.end_time
        )

        session.commands_count = commands.count()
        session.successful_commands = commands.filter(status='completed').count()
        session.failed_commands = commands.filter(status='failed').count()

        if commands.exists():
            avg_confidence = sum(cmd.confidence_score for cmd in commands) / commands.count()
            session.average_confidence = avg_confidence

        session.total_duration = (session.end_time - session.start_time).total_seconds()
        session.save()

        return Response({
            'message': 'Voice session ended',
            'session_stats': VoiceSessionSerializer(session).data
        })

    except VoiceSession.DoesNotExist:
        return Response({
            'error': 'Session not found'
        }, status=status.HTTP_404_NOT_FOUND)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def live_speech_recognition(request):
    """Real-time speech recognition from microphone"""
    try:
        # Get user preferences
        try:
            preferences = VoicePreference.objects.get(user=request.user)
            if not preferences.voice_activation_enabled:
                return Response({
                    'error': 'Voice activation is disabled'
                }, status=status.HTTP_403_FORBIDDEN)
        except VoicePreference.DoesNotExist:
            VoicePreference.objects.create(user=request.user)

        # Listen for speech
        speech_service = SpeechRecognitionService()
        result = speech_service.listen_for_speech(
            timeout=request.data.get('timeout', 5),
            phrase_timeout=request.data.get('phrase_timeout', 1)
        )

        if result['success']:
            return Response({
                'transcribed_text': result['text'],
                'confidence': result['confidence'],
                'success': True
            })
        else:
            return Response({
                'error': result['error'],
                'success': False
            }, status=status.HTTP_400_BAD_REQUEST)

    except Exception as e:
        return Response({
            'error': f'Speech recognition error: {str(e)}',
            'success': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class VoicePreferenceView(generics.RetrieveUpdateAPIView):
    serializer_class = VoicePreferenceSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        preferences, created = VoicePreference.objects.get_or_create(
            user=self.request.user
        )
        return preferences


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def text_to_speech(request):
    """Convert text to speech (placeholder for future TTS implementation)"""
    serializer = TextToSpeechSerializer(data=request.data)

    if serializer.is_valid():
        # This is a placeholder - in a real implementation, you would:
        # 1. Use a TTS service like Google Cloud TTS, Azure Speech, or AWS Polly
        # 2. Generate audio file
        # 3. Return audio file URL or base64 encoded audio

        return Response({
            'message': 'Text-to-speech functionality will be implemented with cloud TTS service',
            'text': serializer.validated_data['text'],
            'audio_url': None  # Would contain actual audio URL
        })

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def voice_analytics_dashboard(request):
    """Get voice command analytics for user"""
    # Get recent analytics
    recent_analytics = VoiceAnalytics.objects.filter(
        user=request.user
    ).order_by('-date')[:30]

    # Get overall statistics
    total_commands = VoiceCommand.objects.filter(user=request.user).count()
    successful_commands = VoiceCommand.objects.filter(
        user=request.user, status='completed'
    ).count()

    success_rate = (successful_commands / total_commands * 100) if total_commands > 0 else 0

    # Get most used commands
    from django.db.models import Count
    command_usage = VoiceCommand.objects.filter(
        user=request.user
    ).values('command_type').annotate(
        count=Count('command_type')
    ).order_by('-count')[:5]

    return Response({
        'total_commands': total_commands,
        'successful_commands': successful_commands,
        'success_rate': success_rate,
        'most_used_commands': list(command_usage),
        'recent_analytics': [
            {
                'date': analytics.date,
                'total_commands': analytics.total_commands,
                'successful_commands': analytics.successful_commands,
                'average_processing_time': analytics.average_processing_time
            }
            for analytics in recent_analytics
        ]
    })


def _update_voice_analytics(user, voice_command):
    """Update daily voice analytics"""
    today = timezone.now().date()
    analytics, created = VoiceAnalytics.objects.get_or_create(
        user=user, date=today
    )

    analytics.total_commands += 1
    if voice_command.status == 'completed':
        analytics.successful_commands += 1

    # Update average processing time
    if analytics.total_commands == 1:
        analytics.average_processing_time = voice_command.processing_time
    else:
        analytics.average_processing_time = (
            (analytics.average_processing_time * (analytics.total_commands - 1) +
             voice_command.processing_time) / analytics.total_commands
        )

    analytics.save()
