import speech_recognition as sr
import re
import json
from django.conf import settings
from django.utils import timezone
from datetime import datetime
import uuid
from .models import VoiceCommand, SpeechPattern, VoiceSession
from recipes.models import Recipe
from grocery_lists.models import GroceryList, GroceryItem
from nutrition.models import MealLog, WaterIntakeLog


class SpeechRecognitionService:
    """Core service for speech recognition and processing"""

    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()

    def transcribe_audio(self, audio_file_path, language='en-US'):
        """Transcribe audio file to text"""
        try:
            with sr.AudioFile(audio_file_path) as source:
                audio = self.recognizer.record(source)

            # Use Google Speech Recognition
            text = self.recognizer.recognize_google(audio, language=language)
            confidence = 0.8  # Google API doesn't return confidence, so we estimate

            return {
                'text': text,
                'confidence': confidence,
                'success': True
            }
        except sr.UnknownValueError:
            return {
                'text': '',
                'confidence': 0.0,
                'success': False,
                'error': 'Could not understand audio'
            }
        except sr.RequestError as e:
            return {
                'text': '',
                'confidence': 0.0,
                'success': False,
                'error': f'Speech recognition service error: {e}'
            }

    def listen_for_speech(self, timeout=5, phrase_timeout=1):
        """Listen for speech from microphone"""
        try:
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source)

            audio = self.recognizer.listen(
                self.microphone,
                timeout=timeout,
                phrase_time_limit=phrase_timeout
            )

            text = self.recognizer.recognize_google(audio)
            return {
                'text': text,
                'confidence': 0.8,
                'success': True
            }
        except sr.WaitTimeoutError:
            return {
                'text': '',
                'confidence': 0.0,
                'success': False,
                'error': 'Listening timeout'
            }
        except sr.UnknownValueError:
            return {
                'text': '',
                'confidence': 0.0,
                'success': False,
                'error': 'Could not understand speech'
            }


class NaturalLanguageProcessor:
    """NLP service for parsing voice commands"""

    def __init__(self):
        self.patterns = self._load_patterns()

    def _load_patterns(self):
        """Load speech patterns from database"""
        patterns = {}
        for pattern in SpeechPattern.objects.filter(is_active=True):
            if pattern.command_type not in patterns:
                patterns[pattern.command_type] = []
            patterns[pattern.command_type].append({
                'pattern': pattern.pattern,
                'priority': pattern.priority
            })
        return patterns

    def parse_command(self, text):
        """Parse transcribed text to extract intent and entities"""
        text = text.lower().strip()

        # Try to match against known patterns
        for command_type, pattern_list in self.patterns.items():
            for pattern_info in pattern_list:
                if self._match_pattern(text, pattern_info['pattern']):
                    entities = self._extract_entities(text, command_type)
                    return {
                        'intent': command_type,
                        'entities': entities,
                        'confidence': 0.9,
                        'original_text': text
                    }

        # Fallback: use keyword matching
        return self._fallback_parsing(text)

    def _match_pattern(self, text, pattern):
        """Check if text matches a pattern"""
        pattern_regex = pattern.replace('{item}', r'(.+?)').replace('{quantity}', r'(\d+(?:\.\d+)?)')
        return bool(re.search(pattern_regex, text, re.IGNORECASE))

    def _extract_entities(self, text, command_type):
        """Extract entities based on command type"""
        entities = {}

        if command_type == 'add_grocery_item':
            # Extract quantity and item name
            quantity_match = re.search(r'(\d+(?:\.\d+)?)\s*(\w+)?\s*(.+)', text)
            if quantity_match:
                entities['quantity'] = float(quantity_match.group(1))
                entities['unit'] = quantity_match.group(2) or 'pieces'
                entities['item_name'] = quantity_match.group(3).strip()
            else:
                # No quantity specified
                entities['quantity'] = 1
                entities['unit'] = 'pieces'
                entities['item_name'] = text.replace('add', '').strip()

        elif command_type == 'search_recipe':
            # Extract search terms
            search_terms = text.replace('search', '').replace('recipe', '').replace('for', '').strip()
            entities['search_query'] = search_terms

        elif command_type == 'log_meal':
            # Extract meal type and recipe name
            meal_types = ['breakfast', 'lunch', 'dinner', 'snack']
            for meal_type in meal_types:
                if meal_type in text:
                    entities['meal_type'] = meal_type
                    break
            else:
                entities['meal_type'] = 'snack'  # default

            # Extract recipe name
            recipe_name = text
            for keyword in ['log', 'ate', 'had', 'consumed', entities['meal_type']]:
                recipe_name = recipe_name.replace(keyword, '')
            entities['recipe_name'] = recipe_name.strip()

        elif command_type == 'log_water':
            # Extract water amount
            amount_match = re.search(r'(\d+(?:\.\d+)?)\s*(liter|litre|l|ml|cup|glass)', text)
            if amount_match:
                amount = float(amount_match.group(1))
                unit = amount_match.group(2)

                # Convert to liters
                if unit in ['ml']:
                    amount = amount / 1000
                elif unit in ['cup']:
                    amount = amount * 0.24  # 1 cup = 0.24 liters
                elif unit in ['glass']:
                    amount = amount * 0.25  # 1 glass = 0.25 liters

                entities['amount'] = amount
            else:
                entities['amount'] = 0.25  # default 1 glass

        return entities

    def _fallback_parsing(self, text):
        """Fallback parsing using keywords"""
        # Simple keyword-based classification
        if any(word in text for word in ['add', 'buy', 'need', 'grocery', 'shopping']):
            return {
                'intent': 'add_grocery_item',
                'entities': {'item_name': text, 'quantity': 1, 'unit': 'pieces'},
                'confidence': 0.6,
                'original_text': text
            }
        elif any(word in text for word in ['search', 'find', 'recipe', 'cook']):
            return {
                'intent': 'search_recipe',
                'entities': {'search_query': text},
                'confidence': 0.6,
                'original_text': text
            }
        elif any(word in text for word in ['ate', 'had', 'consumed', 'log']):
            return {
                'intent': 'log_meal',
                'entities': {'meal_type': 'snack', 'recipe_name': text},
                'confidence': 0.6,
                'original_text': text
            }
        elif any(word in text for word in ['water', 'drink', 'drank']):
            return {
                'intent': 'log_water',
                'entities': {'amount': 0.25},
                'confidence': 0.6,
                'original_text': text
            }
        else:
            return {
                'intent': 'other',
                'entities': {},
                'confidence': 0.3,
                'original_text': text
            }


class VoiceCommandExecutor:
    """Execute parsed voice commands"""

    def __init__(self, user):
        self.user = user

    def execute_command(self, voice_command):
        """Execute a voice command and return results"""
        intent = voice_command.parsed_intent.get('intent')
        entities = voice_command.parsed_intent.get('entities', {})

        try:
            if intent == 'add_grocery_item':
                return self._add_grocery_item(entities)
            elif intent == 'search_recipe':
                return self._search_recipe(entities)
            elif intent == 'log_meal':
                return self._log_meal(entities)
            elif intent == 'log_water':
                return self._log_water(entities)
            else:
                return {
                    'success': False,
                    'message': 'Command not supported yet',
                    'data': {}
                }
        except Exception as e:
            return {
                'success': False,
                'message': f'Error executing command: {str(e)}',
                'data': {}
            }

    def _add_grocery_item(self, entities):
        """Add item to grocery list"""
        # Get or create active grocery list
        grocery_list = GroceryList.objects.filter(
            user=self.user, status='active'
        ).first()

        if not grocery_list:
            grocery_list = GroceryList.objects.create(
                user=self.user,
                name="Voice Commands List",
                status='active'
            )

        # Create grocery item
        item = GroceryItem.objects.create(
            grocery_list=grocery_list,
            name=entities.get('item_name', 'Unknown Item'),
            quantity=entities.get('quantity', 1),
            unit=entities.get('unit', 'pieces'),
            added_by_voice=True
        )

        return {
            'success': True,
            'message': f"Added {item.quantity} {item.unit} of {item.name} to your grocery list",
            'data': {'item_id': item.id, 'grocery_list_id': grocery_list.id}
        }

    def _search_recipe(self, entities):
        """Search for recipes"""
        query = entities.get('search_query', '')
        recipes = Recipe.objects.filter(
            title__icontains=query, is_public=True
        )[:5]

        if recipes:
            recipe_list = [{'id': r.id, 'title': r.title, 'cook_time': r.cook_time} for r in recipes]
            return {
                'success': True,
                'message': f"Found {len(recipes)} recipes matching '{query}'",
                'data': {'recipes': recipe_list}
            }
        else:
            return {
                'success': False,
                'message': f"No recipes found for '{query}'",
                'data': {}
            }

    def _log_meal(self, entities):
        """Log a meal"""
        recipe_name = entities.get('recipe_name', '')
        meal_type = entities.get('meal_type', 'snack')

        # Try to find matching recipe
        recipe = Recipe.objects.filter(
            title__icontains=recipe_name, is_public=True
        ).first()

        if recipe:
            meal_log = MealLog.objects.create(
                user=self.user,
                recipe=recipe,
                meal_type=meal_type,
                servings=1
            )
            return {
                'success': True,
                'message': f"Logged {recipe.title} as {meal_type}",
                'data': {'meal_log_id': meal_log.id}
            }
        else:
            return {
                'success': False,
                'message': f"Could not find recipe '{recipe_name}'",
                'data': {}
            }

    def _log_water(self, entities):
        """Log water intake"""
        amount = entities.get('amount', 0.25)

        water_log = WaterIntakeLog.objects.create(
            user=self.user,
            amount=amount
        )

        return {
            'success': True,
            'message': f"Logged {amount} liters of water",
            'data': {'water_log_id': water_log.id}
        }
