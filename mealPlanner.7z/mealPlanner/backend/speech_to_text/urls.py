from django.urls import path
from . import views

urlpatterns = [
    path('commands/', views.VoiceCommandListCreateView.as_view(), name='voice-commands'),
    path('process/', views.process_voice_command, name='process-voice-command'),
    path('sessions/start/', views.start_voice_session, name='start-voice-session'),
    path('sessions/<str:session_id>/end/', views.end_voice_session, name='end-voice-session'),
    path('live-recognition/', views.live_speech_recognition, name='live-speech-recognition'),
    path('preferences/', views.VoicePreferenceView.as_view(), name='voice-preferences'),
    path('text-to-speech/', views.text_to_speech, name='text-to-speech'),
    path('analytics/', views.voice_analytics_dashboard, name='voice-analytics'),
]
