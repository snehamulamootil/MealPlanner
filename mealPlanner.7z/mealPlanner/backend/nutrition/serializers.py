from rest_framework import serializers
from .models import NutritionGoal, DailyNutrition, MealLog, WaterIntakeLog, NutritionReport, NutrientDeficiency
from recipes.serializers import RecipeSerializer


class NutritionGoalSerializer(serializers.ModelSerializer):
    class Meta:
        model = NutritionGoal
        fields = ('id', 'goal_type', 'target_calories', 'target_protein', 'target_carbs',
                 'target_fat', 'target_fiber', 'target_sugar', 'target_sodium', 'is_active',
                 'created_at', 'updated_at')
        read_only_fields = ('user',)


class DailyNutritionSerializer(serializers.ModelSerializer):
    goal_progress = serializers.SerializerMethodField()

    class Meta:
        model = DailyNutrition
        fields = ('id', 'date', 'calories_consumed', 'protein_consumed', 'carbs_consumed',
                 'fat_consumed', 'fiber_consumed', 'sugar_consumed', 'sodium_consumed',
                 'water_intake', 'goal_progress', 'created_at', 'updated_at')
        read_only_fields = ('user',)

    def get_goal_progress(self, obj):
        try:
            goal = NutritionGoal.objects.get(user=obj.user, is_active=True)
            return {
                'calories_percentage': (obj.calories_consumed / goal.target_calories * 100) if goal.target_calories else 0,
                'protein_percentage': (obj.protein_consumed / goal.target_protein * 100) if goal.target_protein else 0,
                'carbs_percentage': (obj.carbs_consumed / goal.target_carbs * 100) if goal.target_carbs else 0,
                'fat_percentage': (obj.fat_consumed / goal.target_fat * 100) if goal.target_fat else 0,
            }
        except NutritionGoal.DoesNotExist:
            return None


class MealLogSerializer(serializers.ModelSerializer):
    recipe_details = RecipeSerializer(source='recipe', read_only=True)
    calories = serializers.ReadOnlyField()

    class Meta:
        model = MealLog
        fields = ('id', 'recipe', 'recipe_details', 'meal_type', 'servings', 'date',
                 'logged_at', 'notes', 'calories')
        read_only_fields = ('user',)


class WaterIntakeLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = WaterIntakeLog
        fields = ('id', 'amount', 'date', 'logged_at')
        read_only_fields = ('user',)


class NutritionReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = NutritionReport
        fields = ('id', 'report_type', 'start_date', 'end_date', 'average_calories',
                 'average_protein', 'average_carbs', 'average_fat', 'goal_achievement_percentage',
                 'generated_at')
        read_only_fields = ('user',)


class NutrientDeficiencySerializer(serializers.ModelSerializer):
    class Meta:
        model = NutrientDeficiency
        fields = ('id', 'nutrient_name', 'severity', 'recommended_foods', 'detected_at',
                 'resolved_at', 'is_resolved')
        read_only_fields = ('user',)
