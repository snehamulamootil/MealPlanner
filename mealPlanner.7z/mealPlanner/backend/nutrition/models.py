from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator, MaxValueValidator
from datetime import date
from recipes.models import Recipe

User = get_user_model()


class NutritionGoal(models.Model):
    GOAL_TYPE_CHOICES = [
        ('weight_loss', 'Weight Loss'),
        ('weight_gain', 'Weight Gain'),
        ('maintenance', 'Weight Maintenance'),
        ('muscle_gain', 'Muscle Gain'),
        ('general_health', 'General Health'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='nutrition_goals')
    goal_type = models.CharField(max_length=20, choices=GOAL_TYPE_CHOICES)
    target_calories = models.PositiveIntegerField()
    target_protein = models.FloatField(help_text="Grams")
    target_carbs = models.FloatField(help_text="Grams")
    target_fat = models.FloatField(help_text="Grams")
    target_fiber = models.FloatField(help_text="Grams", default=25)
    target_sugar = models.FloatField(help_text="Grams", default=50)
    target_sodium = models.FloatField(help_text="Milligrams", default=2300)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'is_active')

    def __str__(self):
        return f"{self.user.username}'s {self.goal_type} goal"

    @classmethod
    def calculate_goals(cls, user):
        """Calculate nutrition goals based on user profile"""
        if not all([user.weight, user.height]):
            return None

        # Basic BMR calculation using Mifflin-St Jeor Equation
        if user.gender == 'male':
            bmr = 10 * user.weight + 6.25 * user.height - 5 * user.age + 5
        else:
            bmr = 10 * user.weight + 6.25 * user.height - 5 * user.age - 161

        # Activity factor
        activity_factors = {
            'sedentary': 1.2,
            'lightly_active': 1.375,
            'moderately_active': 1.55,
            'very_active': 1.725,
            'extra_active': 1.9
        }

        tdee = bmr * activity_factors.get(user.activity_level, 1.55)

        return {
            'calories': int(tdee),
            'protein': user.weight * 1.6,  # 1.6g per kg body weight
            'carbs': (tdee * 0.45) / 4,    # 45% of calories from carbs
            'fat': (tdee * 0.25) / 9,      # 25% of calories from fat
        }


class DailyNutrition(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='daily_nutrition')
    date = models.DateField(default=date.today)
    calories_consumed = models.FloatField(default=0)
    protein_consumed = models.FloatField(default=0)
    carbs_consumed = models.FloatField(default=0)
    fat_consumed = models.FloatField(default=0)
    fiber_consumed = models.FloatField(default=0)
    sugar_consumed = models.FloatField(default=0)
    sodium_consumed = models.FloatField(default=0)
    water_intake = models.FloatField(default=0, help_text="Liters")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'date')
        ordering = ['-date']

    def __str__(self):
        return f"{self.user.username} - {self.date}"

    def update_from_meal(self, recipe, servings=1):
        """Update nutrition values from a consumed meal"""
        self.calories_consumed += recipe.total_calories * servings
        # Add other nutrient calculations based on recipe ingredients
        self.save()


class MealLog(models.Model):
    MEAL_TYPE_CHOICES = [
        ('breakfast', 'Breakfast'),
        ('lunch', 'Lunch'),
        ('dinner', 'Dinner'),
        ('snack', 'Snack'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='meal_logs')
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE)
    meal_type = models.CharField(max_length=10, choices=MEAL_TYPE_CHOICES)
    servings = models.FloatField(default=1)
    date = models.DateField(default=date.today)
    logged_at = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['-date', 'meal_type']

    def __str__(self):
        return f"{self.user.username} - {self.recipe.title} ({self.date})"

    @property
    def calories(self):
        return self.recipe.total_calories * self.servings

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Update daily nutrition
        daily_nutrition, created = DailyNutrition.objects.get_or_create(
            user=self.user, date=self.date
        )
        daily_nutrition.update_from_meal(self.recipe, self.servings)


class WaterIntakeLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='water_logs')
    amount = models.FloatField(help_text="Amount in liters")
    date = models.DateField(default=date.today)
    logged_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.amount}L ({self.date})"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Update daily nutrition water intake
        daily_nutrition, created = DailyNutrition.objects.get_or_create(
            user=self.user, date=self.date
        )
        daily_nutrition.water_intake += self.amount
        daily_nutrition.save()


class NutritionReport(models.Model):
    REPORT_TYPE_CHOICES = [
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='nutrition_reports')
    report_type = models.CharField(max_length=10, choices=REPORT_TYPE_CHOICES)
    start_date = models.DateField()
    end_date = models.DateField()
    average_calories = models.FloatField(default=0)
    average_protein = models.FloatField(default=0)
    average_carbs = models.FloatField(default=0)
    average_fat = models.FloatField(default=0)
    goal_achievement_percentage = models.FloatField(default=0)
    generated_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.report_type} report ({self.start_date} to {self.end_date})"


class NutrientDeficiency(models.Model):
    SEVERITY_CHOICES = [
        ('mild', 'Mild'),
        ('moderate', 'Moderate'),
        ('severe', 'Severe'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='nutrient_deficiencies')
    nutrient_name = models.CharField(max_length=100)
    severity = models.CharField(max_length=10, choices=SEVERITY_CHOICES)
    recommended_foods = models.JSONField(default=list)
    detected_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    is_resolved = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user.username} - {self.nutrient_name} deficiency"
