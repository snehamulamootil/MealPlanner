from django.urls import path
from . import views

urlpatterns = [
    path('goals/', views.NutritionGoalListCreateView.as_view(), name='nutrition-goals'),
    path('daily/', views.DailyNutritionListView.as_view(), name='daily-nutrition'),
    path('meals/', views.MealLogListCreateView.as_view(), name='meal-logs'),
    path('water/', views.WaterIntakeListCreateView.as_view(), name='water-intake'),
    path('dashboard/', views.nutrition_dashboard, name='nutrition-dashboard'),
    path('reports/generate/', views.generate_nutrition_report, name='generate-nutrition-report'),
    path('goals/auto-calculate/', views.auto_calculate_goals, name='auto-calculate-goals'),
]
