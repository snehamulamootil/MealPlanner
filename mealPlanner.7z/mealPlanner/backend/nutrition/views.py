from rest_framework import generics, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.db.models import Avg, Sum
from datetime import date, timedelta
from .models import NutritionGoal, DailyNutrition, MealLog, WaterIntakeLog, NutritionReport, NutrientDeficiency
from .serializers import (
    NutritionGoalSerializer, DailyNutritionSerializer, MealLogSerializer,
    WaterIntakeLogSerializer, NutritionReportSerializer, NutrientDeficiencySerializer
)


class NutritionGoalListCreateView(generics.ListCreateAPIView):
    serializer_class = NutritionGoalSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return NutritionGoal.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        # Deactivate other goals when creating a new one
        NutritionGoal.objects.filter(user=self.request.user, is_active=True).update(is_active=False)
        serializer.save(user=self.request.user)


class DailyNutritionListView(generics.ListAPIView):
    serializer_class = DailyNutritionSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return DailyNutrition.objects.filter(user=self.request.user).order_by('-date')


class MealLogListCreateView(generics.ListCreateAPIView):
    serializer_class = MealLogSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return MealLog.objects.filter(user=self.request.user).select_related('recipe')

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class WaterIntakeListCreateView(generics.ListCreateAPIView):
    serializer_class = WaterIntakeLogSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return WaterIntakeLog.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def nutrition_dashboard(request):
    """Get comprehensive nutrition dashboard data"""
    user = request.user
    today = date.today()

    # Get today's nutrition
    today_nutrition, _ = DailyNutrition.objects.get_or_create(user=user, date=today)

    # Get active nutrition goal
    try:
        active_goal = NutritionGoal.objects.get(user=user, is_active=True)
    except NutritionGoal.DoesNotExist:
        active_goal = None

    # Calculate weekly averages
    week_start = today - timedelta(days=7)
    weekly_nutrition = DailyNutrition.objects.filter(
        user=user, date__gte=week_start
    ).aggregate(
        avg_calories=Avg('calories_consumed'),
        avg_protein=Avg('protein_consumed'),
        avg_carbs=Avg('carbs_consumed'),
        avg_fat=Avg('fat_consumed'),
        avg_water=Avg('water_intake')
    )

    # Get recent meal logs
    recent_meals = MealLog.objects.filter(user=user).order_by('-logged_at')[:10]

    # Calculate goal progress
    goal_progress = None
    if active_goal:
        goal_progress = {
            'calories': {
                'consumed': today_nutrition.calories_consumed,
                'target': active_goal.target_calories,
                'percentage': (today_nutrition.calories_consumed / active_goal.target_calories * 100) if active_goal.target_calories else 0
            },
            'protein': {
                'consumed': today_nutrition.protein_consumed,
                'target': active_goal.target_protein,
                'percentage': (today_nutrition.protein_consumed / active_goal.target_protein * 100) if active_goal.target_protein else 0
            },
            'carbs': {
                'consumed': today_nutrition.carbs_consumed,
                'target': active_goal.target_carbs,
                'percentage': (today_nutrition.carbs_consumed / active_goal.target_carbs * 100) if active_goal.target_carbs else 0
            },
            'fat': {
                'consumed': today_nutrition.fat_consumed,
                'target': active_goal.target_fat,
                'percentage': (today_nutrition.fat_consumed / active_goal.target_fat * 100) if active_goal.target_fat else 0
            }
        }

    return Response({
        'today_nutrition': DailyNutritionSerializer(today_nutrition).data,
        'active_goal': NutritionGoalSerializer(active_goal).data if active_goal else None,
        'goal_progress': goal_progress,
        'weekly_averages': weekly_nutrition,
        'recent_meals': MealLogSerializer(recent_meals, many=True).data
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def generate_nutrition_report(request):
    """Generate detailed nutrition report"""
    report_type = request.data.get('report_type', 'weekly')
    end_date = date.today()

    if report_type == 'daily':
        start_date = end_date
    elif report_type == 'weekly':
        start_date = end_date - timedelta(days=7)
    else:  # monthly
        start_date = end_date - timedelta(days=30)

    # Calculate averages for the period
    nutrition_data = DailyNutrition.objects.filter(
        user=request.user, date__range=[start_date, end_date]
    ).aggregate(
        avg_calories=Avg('calories_consumed'),
        avg_protein=Avg('protein_consumed'),
        avg_carbs=Avg('carbs_consumed'),
        avg_fat=Avg('fat_consumed')
    )

    # Calculate goal achievement
    try:
        goal = NutritionGoal.objects.get(user=request.user, is_active=True)
        goal_achievement = (
            (nutrition_data['avg_calories'] or 0) / goal.target_calories * 100
        ) if goal.target_calories else 0
    except NutritionGoal.DoesNotExist:
        goal_achievement = 0

    # Create report
    report = NutritionReport.objects.create(
        user=request.user,
        report_type=report_type,
        start_date=start_date,
        end_date=end_date,
        average_calories=nutrition_data['avg_calories'] or 0,
        average_protein=nutrition_data['avg_protein'] or 0,
        average_carbs=nutrition_data['avg_carbs'] or 0,
        average_fat=nutrition_data['avg_fat'] or 0,
        goal_achievement_percentage=goal_achievement
    )

    return Response({
        'message': 'Report generated successfully',
        'report': NutritionReportSerializer(report).data
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def auto_calculate_goals(request):
    """Auto-calculate nutrition goals based on user profile"""
    user = request.user
    calculated_goals = NutritionGoal.calculate_goals(user)

    if not calculated_goals:
        return Response({
            'error': 'Unable to calculate goals. Please update your profile with weight and height.'
        }, status=status.HTTP_400_BAD_REQUEST)

    # Deactivate existing goals
    NutritionGoal.objects.filter(user=user, is_active=True).update(is_active=False)

    # Create new goal
    goal = NutritionGoal.objects.create(
        user=user,
        goal_type='general_health',
        target_calories=calculated_goals['calories'],
        target_protein=calculated_goals['protein'],
        target_carbs=calculated_goals['carbs'],
        target_fat=calculated_goals['fat']
    )

    return Response({
        'message': 'Nutrition goals calculated and set successfully',
        'goal': NutritionGoalSerializer(goal).data
    })
