from django.urls import path
from . import views

urlpatterns = [
    path('categories/', views.CategoryListCreateView.as_view(), name='category-list'),
    path('ingredients/', views.IngredientListCreateView.as_view(), name='ingredient-list'),
    path('', views.RecipeListCreateView.as_view(), name='recipe-list'),
    path('<int:pk>/', views.RecipeDetailView.as_view(), name='recipe-detail'),
    path('<int:recipe_id>/reviews/', views.RecipeReviewCreateView.as_view(), name='recipe-review'),
    path('<int:recipe_id>/favorite/', views.toggle_favorite_recipe, name='toggle-favorite'),
    path('favorites/', views.FavoriteRecipeListView.as_view(), name='favorite-recipes'),
    path('suggestions/', views.recipe_suggestions, name='recipe-suggestions'),
]
