from rest_framework import serializers
from .models import Category, Ingredient, Recipe, RecipeIngredient, RecipeReview, FavoriteRecipe


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'


class IngredientSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ingredient
        fields = '__all__'


class RecipeIngredientSerializer(serializers.ModelSerializer):
    ingredient_name = serializers.CharField(source='ingredient.name', read_only=True)
    calories = serializers.ReadOnlyField()
    estimated_cost = serializers.ReadOnlyField()

    class Meta:
        model = RecipeIngredient
        fields = ('id', 'ingredient', 'ingredient_name', 'quantity', 'unit', 'notes', 'calories', 'estimated_cost')


class RecipeReviewSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source='user.username', read_only=True)

    class Meta:
        model = RecipeReview
        fields = ('id', 'user', 'user_name', 'rating', 'comment', 'created_at')
        read_only_fields = ('user',)


class RecipeSerializer(serializers.ModelSerializer):
    recipe_ingredients = RecipeIngredientSerializer(many=True, read_only=True)
    reviews = RecipeReviewSerializer(many=True, read_only=True)
    created_by_name = serializers.CharField(source='created_by.username', read_only=True)
    total_time = serializers.ReadOnlyField()
    total_calories = serializers.ReadOnlyField()
    estimated_cost = serializers.ReadOnlyField()
    is_favorite = serializers.SerializerMethodField()

    class Meta:
        model = Recipe
        fields = ('id', 'title', 'description', 'instructions', 'prep_time', 'cook_time',
                 'servings', 'difficulty', 'meal_type', 'cuisine_type', 'image', 'categories',
                 'created_by', 'created_by_name', 'is_public', 'rating', 'created_at', 'updated_at',
                 'recipe_ingredients', 'reviews', 'total_time', 'total_calories', 'estimated_cost',
                 'is_favorite')
        read_only_fields = ('created_by', 'rating')

    def get_is_favorite(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            return FavoriteRecipe.objects.filter(user=request.user, recipe=obj).exists()
        return False


class RecipeCreateSerializer(serializers.ModelSerializer):
    ingredients = serializers.ListField(write_only=True)

    class Meta:
        model = Recipe
        fields = ('title', 'description', 'instructions', 'prep_time', 'cook_time',
                 'servings', 'difficulty', 'meal_type', 'cuisine_type', 'image', 'categories',
                 'is_public', 'ingredients')

    def create(self, validated_data):
        ingredients_data = validated_data.pop('ingredients')
        recipe = Recipe.objects.create(**validated_data)

        for ingredient_data in ingredients_data:
            RecipeIngredient.objects.create(
                recipe=recipe,
                ingredient_id=ingredient_data['ingredient_id'],
                quantity=ingredient_data['quantity'],
                unit=ingredient_data['unit'],
                notes=ingredient_data.get('notes', '')
            )
        return recipe


class FavoriteRecipeSerializer(serializers.ModelSerializer):
    recipe_title = serializers.CharField(source='recipe.title', read_only=True)

    class Meta:
        model = FavoriteRecipe
        fields = ('id', 'recipe', 'recipe_title', 'created_at')
        read_only_fields = ('user',)
