from rest_framework import generics, status, filters
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, IsAuthenticatedOrReadOnly
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Q, Avg
from .models import Category, Ingredient, Recipe, RecipeReview, FavoriteRecipe
from .serializers import (
    CategorySerializer, IngredientSerializer, RecipeSerializer,
    RecipeCreateSerializer, RecipeReviewSerializer, FavoriteRecipeSerializer
)


class CategoryListCreateView(generics.ListCreateAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsAuthenticatedOrReadOnly]


class IngredientListCreateView(generics.ListCreateAPIView):
    queryset = Ingredient.objects.all()
    serializer_class = IngredientSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    search_fields = ['name', 'category__name']
    filterset_fields = ['category']


class RecipeListCreateView(generics.ListCreateAPIView):
    serializer_class = RecipeSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['title', 'description', 'cuisine_type', 'categories__name']
    filterset_fields = ['meal_type', 'difficulty', 'categories', 'created_by']
    ordering_fields = ['created_at', 'rating', 'prep_time', 'cook_time']
    ordering = ['-created_at']

    def get_queryset(self):
        queryset = Recipe.objects.filter(is_public=True)
        if self.request.user.is_authenticated:
            # Include user's private recipes
            queryset = Recipe.objects.filter(
                Q(is_public=True) | Q(created_by=self.request.user)
            )
        return queryset.prefetch_related('recipe_ingredients__ingredient', 'reviews', 'categories')

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return RecipeCreateSerializer
        return RecipeSerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class RecipeDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = RecipeSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        return Recipe.objects.filter(
            Q(is_public=True) | Q(created_by=self.request.user)
        ).prefetch_related('recipe_ingredients__ingredient', 'reviews')


class RecipeReviewCreateView(generics.CreateAPIView):
    serializer_class = RecipeReviewSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        recipe = Recipe.objects.get(pk=self.kwargs['recipe_id'])
        serializer.save(user=self.request.user, recipe=recipe)

        # Update recipe rating
        avg_rating = RecipeReview.objects.filter(recipe=recipe).aggregate(
            avg_rating=Avg('rating')
        )['avg_rating']
        recipe.rating = round(avg_rating, 1) if avg_rating else 0
        recipe.save()


@api_view(['POST', 'DELETE'])
@permission_classes([IsAuthenticated])
def toggle_favorite_recipe(request, recipe_id):
    try:
        recipe = Recipe.objects.get(id=recipe_id)
        favorite, created = FavoriteRecipe.objects.get_or_create(
            user=request.user, recipe=recipe
        )

        if not created:
            favorite.delete()
            return Response({'message': 'Recipe removed from favorites'})
        else:
            return Response({'message': 'Recipe added to favorites'})
    except Recipe.DoesNotExist:
        return Response({'error': 'Recipe not found'}, status=status.HTTP_404_NOT_FOUND)


class FavoriteRecipeListView(generics.ListAPIView):
    serializer_class = FavoriteRecipeSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return FavoriteRecipe.objects.filter(user=self.request.user).select_related('recipe')


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def recipe_suggestions(request):
    """Get recipe suggestions based on user preferences and dietary restrictions"""
    user = request.user

    # Base queryset
    recipes = Recipe.objects.filter(is_public=True)

    # Filter by dietary preferences
    if user.dietary_preferences:
        for preference in user.dietary_preferences:
            recipes = recipes.filter(
                Q(title__icontains=preference) |
                Q(description__icontains=preference) |
                Q(categories__name__icontains=preference)
            )

    # Exclude allergies
    if user.allergies:
        for allergy in user.allergies:
            recipes = recipes.exclude(
                recipe_ingredients__ingredient__name__icontains=allergy
            )

    # Get top-rated recipes
    recipes = recipes.order_by('-rating', '-created_at')[:10]

    serializer = RecipeSerializer(recipes, many=True, context={'request': request})
    return Response(serializer.data)
