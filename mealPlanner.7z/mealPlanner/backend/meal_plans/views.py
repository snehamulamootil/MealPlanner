from rest_framework import generics, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.db.models import Q
from datetime import datetime, date, timedelta
from collections import defaultdict
from .models import MealPlan, PlannedMeal, MealPlanTemplate, ShoppingList, ShoppingListItem
from .serializers import (
    MealPlanSerializer, MealPlanCreateSerializer, PlannedMealSerializer,
    MealPlanTemplateSerializer, ShoppingListSerializer, DragDropMealSerializer
)
from recipes.models import Recipe, RecipeIngredient


class MealPlanListCreateView(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return MealPlanCreateSerializer
        return MealPlanSerializer

    def get_queryset(self):
        return MealPlan.objects.filter(user=self.request.user).prefetch_related(
            'planned_meals__recipe'
        )

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class MealPlanDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = MealPlanSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return MealPlan.objects.filter(user=self.request.user)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def drag_drop_meal(request, meal_plan_id):
    """Handle drag and drop operations for meal planning"""
    try:
        meal_plan = MealPlan.objects.get(id=meal_plan_id, user=request.user)
        serializer = DragDropMealSerializer(data=request.data)

        if serializer.is_valid():
            data = serializer.validated_data
            recipe = Recipe.objects.get(id=data['recipe_id'])

            # Check if moving existing meal or adding new one
            if data.get('source_day') and data.get('source_meal_type'):
                # Moving existing meal
                try:
                    existing_meal = PlannedMeal.objects.get(
                        meal_plan=meal_plan,
                        day_of_week=data['source_day'],
                        meal_type=data['source_meal_type'],
                        recipe=recipe
                    )
                    existing_meal.day_of_week = data['target_day']
                    existing_meal.meal_type = data['target_meal_type']
                    existing_meal.date = data['date']
                    existing_meal.servings = data['servings']
                    existing_meal.save()

                    return Response({
                        'message': 'Meal moved successfully',
                        'meal': PlannedMealSerializer(existing_meal).data
                    })
                except PlannedMeal.DoesNotExist:
                    return Response({'error': 'Source meal not found'}, status=status.HTTP_404_NOT_FOUND)
            else:
                # Adding new meal
                planned_meal, created = PlannedMeal.objects.get_or_create(
                    meal_plan=meal_plan,
                    recipe=recipe,
                    day_of_week=data['target_day'],
                    meal_type=data['target_meal_type'],
                    defaults={
                        'servings': data['servings'],
                        'date': data['date']
                    }
                )

                if not created:
                    planned_meal.servings = data['servings']
                    planned_meal.save()

                return Response({
                    'message': 'Meal added successfully',
                    'meal': PlannedMealSerializer(planned_meal).data
                })

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    except MealPlan.DoesNotExist:
        return Response({'error': 'Meal plan not found'}, status=status.HTTP_404_NOT_FOUND)
    except Recipe.DoesNotExist:
        return Response({'error': 'Recipe not found'}, status=status.HTTP_404_NOT_FOUND)


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def remove_planned_meal(request, meal_plan_id, planned_meal_id):
    """Remove a planned meal from the meal plan"""
    try:
        meal_plan = MealPlan.objects.get(id=meal_plan_id, user=request.user)
        planned_meal = PlannedMeal.objects.get(id=planned_meal_id, meal_plan=meal_plan)
        planned_meal.delete()
        return Response({'message': 'Meal removed successfully'})
    except (MealPlan.DoesNotExist, PlannedMeal.DoesNotExist):
        return Response({'error': 'Meal not found'}, status=status.HTTP_404_NOT_FOUND)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def generate_shopping_list(request, meal_plan_id):
    """Generate shopping list from meal plan"""
    try:
        meal_plan = MealPlan.objects.get(id=meal_plan_id, user=request.user)

        # Get or create shopping list
        shopping_list, created = ShoppingList.objects.get_or_create(
            meal_plan=meal_plan,
            defaults={'name': f"Shopping List for {meal_plan.name}"}
        )

        # Clear existing items
        shopping_list.items.all().delete()

        # Aggregate ingredients from all planned meals
        ingredient_totals = defaultdict(lambda: {'quantity': 0, 'unit': '', 'price': 0})

        for planned_meal in meal_plan.planned_meals.all():
            for recipe_ingredient in planned_meal.recipe.recipe_ingredients.all():
                ingredient_name = recipe_ingredient.ingredient.name
                quantity = recipe_ingredient.quantity * planned_meal.servings
                unit = recipe_ingredient.unit
                price = recipe_ingredient.estimated_cost * planned_meal.servings

                # Simple aggregation - in real app, you'd handle unit conversions
                if ingredient_totals[ingredient_name]['unit'] == unit or not ingredient_totals[ingredient_name]['unit']:
                    ingredient_totals[ingredient_name]['quantity'] += quantity
                    ingredient_totals[ingredient_name]['unit'] = unit
                    ingredient_totals[ingredient_name]['price'] += price
                else:
                    # Handle different units - simplified approach
                    ingredient_totals[f"{ingredient_name} ({unit})"] = {
                        'quantity': quantity,
                        'unit': unit,
                        'price': price
                    }

        # Create shopping list items
        total_cost = 0
        for ingredient_name, data in ingredient_totals.items():
            ShoppingListItem.objects.create(
                shopping_list=shopping_list,
                ingredient_name=ingredient_name,
                quantity=data['quantity'],
                unit=data['unit'],
                estimated_price=data['price']
            )
            total_cost += data['price']

        shopping_list.total_estimated_cost = total_cost
        shopping_list.is_generated = True
        shopping_list.save()

        return Response({
            'message': 'Shopping list generated successfully',
            'shopping_list': ShoppingListSerializer(shopping_list).data
        })

    except MealPlan.DoesNotExist:
        return Response({'error': 'Meal plan not found'}, status=status.HTTP_404_NOT_FOUND)


class MealPlanTemplateListView(generics.ListCreateAPIView):
    serializer_class = MealPlanTemplateSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return MealPlanTemplate.objects.filter(
            Q(is_public=True) | Q(created_by=self.request.user)
        )

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_meal_plan_from_template(request, template_id):
    """Create a meal plan from a template"""
    try:
        template = MealPlanTemplate.objects.get(id=template_id)
        start_date = datetime.strptime(request.data.get('start_date'), '%Y-%m-%d').date()

        meal_plan = MealPlan.objects.create(
            user=request.user,
            name=f"{template.name} - {start_date}",
            start_date=start_date,
            end_date=start_date + timedelta(days=6)
        )

        # Create planned meals from template
        for template_meal in template.template_meals.all():
            # Calculate the actual date based on day of week
            days_ahead = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].index(template_meal.day_of_week)
            meal_date = start_date + timedelta(days=days_ahead)

            PlannedMeal.objects.create(
                meal_plan=meal_plan,
                recipe=template_meal.recipe,
                day_of_week=template_meal.day_of_week,
                meal_type=template_meal.meal_type,
                servings=template_meal.servings,
                date=meal_date
            )

        return Response({
            'message': 'Meal plan created from template',
            'meal_plan': MealPlanSerializer(meal_plan).data
        })

    except MealPlanTemplate.DoesNotExist:
        return Response({'error': 'Template not found'}, status=status.HTTP_404_NOT_FOUND)
