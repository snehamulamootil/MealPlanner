from django.urls import path
from . import views

urlpatterns = [
    path('', views.MealPlanListCreateView.as_view(), name='meal-plan-list'),
    path('<int:pk>/', views.MealPlanDetailView.as_view(), name='meal-plan-detail'),
    path('<int:meal_plan_id>/drag-drop/', views.drag_drop_meal, name='drag-drop-meal'),
    path('<int:meal_plan_id>/meals/<int:planned_meal_id>/remove/', views.remove_planned_meal, name='remove-planned-meal'),
    path('<int:meal_plan_id>/shopping-list/', views.generate_shopping_list, name='generate-shopping-list'),
    path('templates/', views.MealPlanTemplateListView.as_view(), name='meal-plan-templates'),
    path('templates/<int:template_id>/create-plan/', views.create_meal_plan_from_template, name='create-from-template'),
]
