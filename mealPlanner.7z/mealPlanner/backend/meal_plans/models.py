from django.db import models
from django.contrib.auth import get_user_model
from recipes.models import Recipe
from datetime import date, timedelta

User = get_user_model()


class MealPlan(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='meal_plans')
    name = models.CharField(max_length=200, default="Weekly Meal Plan")
    start_date = models.DateField()
    end_date = models.DateField()
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'start_date', 'end_date')
        ordering = ['-start_date']

    def __str__(self):
        return f"{self.user.username}'s {self.name} ({self.start_date} to {self.end_date})"

    @property
    def total_estimated_cost(self):
        return sum(meal.estimated_cost for meal in self.planned_meals.all())

    @property
    def total_calories(self):
        return sum(meal.total_calories for meal in self.planned_meals.all())

    def save(self, *args, **kwargs):
        if not self.end_date:
            self.end_date = self.start_date + timedelta(days=6)
        super().save(*args, **kwargs)


class PlannedMeal(models.Model):
    MEAL_TYPE_CHOICES = [
        ('breakfast', 'Breakfast'),
        ('lunch', 'Lunch'),
        ('dinner', 'Dinner'),
        ('snack', 'Snack'),
    ]

    DAYS_OF_WEEK = [
        ('monday', 'Monday'),
        ('tuesday', 'Tuesday'),
        ('wednesday', 'Wednesday'),
        ('thursday', 'Thursday'),
        ('friday', 'Friday'),
        ('saturday', 'Saturday'),
        ('sunday', 'Sunday'),
    ]

    meal_plan = models.ForeignKey(MealPlan, on_delete=models.CASCADE, related_name='planned_meals')
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE)
    day_of_week = models.CharField(max_length=10, choices=DAYS_OF_WEEK)
    meal_type = models.CharField(max_length=10, choices=MEAL_TYPE_CHOICES)
    servings = models.PositiveIntegerField(default=1)
    date = models.DateField()
    notes = models.TextField(blank=True)
    is_completed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('meal_plan', 'day_of_week', 'meal_type', 'recipe')
        ordering = ['date', 'meal_type']

    def __str__(self):
        return f"{self.recipe.title} - {self.day_of_week} {self.meal_type}"

    @property
    def estimated_cost(self):
        return self.recipe.estimated_cost * self.servings

    @property
    def total_calories(self):
        return self.recipe.total_calories * self.servings


class MealPlanTemplate(models.Model):
    """Pre-defined meal plan templates for quick setup"""
    name = models.CharField(max_length=200)
    description = models.TextField()
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    is_public = models.BooleanField(default=False)
    tags = models.JSONField(default=list, blank=True)  # e.g., ['vegetarian', 'low-carb', 'budget-friendly']
    estimated_weekly_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class TemplateMeal(models.Model):
    """Meals included in a meal plan template"""
    template = models.ForeignKey(MealPlanTemplate, on_delete=models.CASCADE, related_name='template_meals')
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE)
    day_of_week = models.CharField(max_length=10, choices=PlannedMeal.DAYS_OF_WEEK)
    meal_type = models.CharField(max_length=10, choices=PlannedMeal.MEAL_TYPE_CHOICES)
    servings = models.PositiveIntegerField(default=1)

    class Meta:
        unique_together = ('template', 'day_of_week', 'meal_type')

    def __str__(self):
        return f"{self.template.name} - {self.recipe.title}"


class ShoppingList(models.Model):
    """Auto-generated shopping lists from meal plans"""
    meal_plan = models.OneToOneField(MealPlan, on_delete=models.CASCADE, related_name='shopping_list')
    name = models.CharField(max_length=200)
    is_generated = models.BooleanField(default=False)
    total_estimated_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Shopping list for {self.meal_plan.name}"


class ShoppingListItem(models.Model):
    shopping_list = models.ForeignKey(ShoppingList, on_delete=models.CASCADE, related_name='items')
    ingredient_name = models.CharField(max_length=200)
    quantity = models.FloatField()
    unit = models.CharField(max_length=20)
    estimated_price = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    is_purchased = models.BooleanField(default=False)
    category = models.CharField(max_length=100, blank=True)  # e.g., 'produce', 'dairy', 'meat'
    notes = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return f"{self.quantity} {self.unit} {self.ingredient_name}"
