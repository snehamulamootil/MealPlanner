from rest_framework import serializers
from .models import MealPlan, PlannedMeal, MealPlanTemplate, TemplateMeal, ShoppingList, ShoppingListItem
from recipes.serializers import RecipeSerializer


class PlannedMealSerializer(serializers.ModelSerializer):
    recipe_details = RecipeSerializer(source='recipe', read_only=True)
    estimated_cost = serializers.ReadOnlyField()
    total_calories = serializers.ReadOnlyField()

    class Meta:
        model = PlannedMeal
        fields = ('id', 'recipe', 'recipe_details', 'day_of_week', 'meal_type',
                 'servings', 'date', 'notes', 'is_completed', 'estimated_cost',
                 'total_calories', 'created_at')


class MealPlanSerializer(serializers.ModelSerializer):
    planned_meals = PlannedMealSerializer(many=True, read_only=True)
    total_estimated_cost = serializers.ReadOnlyField()
    total_calories = serializers.ReadOnlyField()

    class Meta:
        model = MealPlan
        fields = ('id', 'name', 'start_date', 'end_date', 'is_active',
                 'planned_meals', 'total_estimated_cost', 'total_calories',
                 'created_at', 'updated_at')
        read_only_fields = ('user',)


class MealPlanCreateSerializer(serializers.ModelSerializer):
    meals = serializers.ListField(write_only=True, required=False)

    class Meta:
        model = MealPlan
        fields = ('name', 'start_date', 'end_date', 'is_active', 'meals')

    def create(self, validated_data):
        meals_data = validated_data.pop('meals', [])
        meal_plan = MealPlan.objects.create(**validated_data)

        for meal_data in meals_data:
            PlannedMeal.objects.create(
                meal_plan=meal_plan,
                recipe_id=meal_data['recipe_id'],
                day_of_week=meal_data['day_of_week'],
                meal_type=meal_data['meal_type'],
                servings=meal_data.get('servings', 1),
                date=meal_data['date'],
                notes=meal_data.get('notes', '')
            )
        return meal_plan


class TemplateMealSerializer(serializers.ModelSerializer):
    recipe_details = RecipeSerializer(source='recipe', read_only=True)

    class Meta:
        model = TemplateMeal
        fields = ('id', 'recipe', 'recipe_details', 'day_of_week', 'meal_type', 'servings')


class MealPlanTemplateSerializer(serializers.ModelSerializer):
    template_meals = TemplateMealSerializer(many=True, read_only=True)
    created_by_name = serializers.CharField(source='created_by.username', read_only=True)

    class Meta:
        model = MealPlanTemplate
        fields = ('id', 'name', 'description', 'created_by', 'created_by_name',
                 'is_public', 'tags', 'estimated_weekly_cost', 'template_meals', 'created_at')
        read_only_fields = ('created_by',)


class ShoppingListItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShoppingListItem
        fields = ('id', 'ingredient_name', 'quantity', 'unit', 'estimated_price',
                 'is_purchased', 'category', 'notes')


class ShoppingListSerializer(serializers.ModelSerializer):
    items = ShoppingListItemSerializer(many=True, read_only=True)

    class Meta:
        model = ShoppingList
        fields = ('id', 'name', 'is_generated', 'total_estimated_cost',
                 'items', 'created_at', 'updated_at')


class DragDropMealSerializer(serializers.Serializer):
    """Serializer for handling drag and drop meal operations"""
    recipe_id = serializers.IntegerField()
    source_day = serializers.CharField(required=False)
    source_meal_type = serializers.CharField(required=False)
    target_day = serializers.CharField()
    target_meal_type = serializers.CharField()
    servings = serializers.IntegerField(default=1)
    date = serializers.DateField()

    def validate_target_day(self, value):
        valid_days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
        if value not in valid_days:
            raise serializers.ValidationError("Invalid day of week")
        return value

    def validate_target_meal_type(self, value):
        valid_types = ['breakfast', 'lunch', 'dinner', 'snack']
        if value not in valid_types:
            raise serializers.ValidationError("Invalid meal type")
        return value
