from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator
from decimal import Decimal

User = get_user_model()


class Store(models.Model):
    name = models.CharField(max_length=200)
    address = models.TextField(blank=True)
    phone = models.CharField(max_length=20, blank=True)
    website = models.URLField(blank=True)
    is_online = models.BooleanField(default=False)
    average_rating = models.FloatField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class GroceryCategory(models.Model):
    name = models.CharField(max_length=100, unique=True)
    icon = models.CharField(max_length=50, blank=True)  # Icon class name
    color = models.CharField(max_length=7, default='#007bff')  # Hex color code
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name_plural = "Grocery Categories"
        ordering = ['sort_order', 'name']

    def __str__(self):
        return self.name


class GroceryList(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('active', 'Active'),
        ('completed', 'Completed'),
        ('archived', 'Archived'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='grocery_lists')
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    budget_limit = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    store = models.ForeignKey(Store, on_delete=models.SET_NULL, null=True, blank=True)
    due_date = models.DateTimeField(null=True, blank=True)
    is_shared = models.BooleanField(default=False)
    shared_with = models.ManyToManyField(User, blank=True, related_name='shared_grocery_lists')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.name

    @property
    def total_estimated_cost(self):
        return sum(item.total_estimated_cost for item in self.items.all())

    @property
    def total_actual_cost(self):
        return sum(item.total_actual_cost for item in self.items.filter(is_purchased=True))

    @property
    def completion_percentage(self):
        total_items = self.items.count()
        if total_items == 0:
            return 0
        purchased_items = self.items.filter(is_purchased=True).count()
        return round((purchased_items / total_items) * 100, 1)

    @property
    def is_over_budget(self):
        if not self.budget_limit:
            return False
        return self.total_estimated_cost > self.budget_limit


class GroceryItem(models.Model):
    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    ]

    grocery_list = models.ForeignKey(GroceryList, on_delete=models.CASCADE, related_name='items')
    name = models.CharField(max_length=200)
    category = models.ForeignKey(GroceryCategory, on_delete=models.SET_NULL, null=True, blank=True)
    brand = models.CharField(max_length=100, blank=True)
    quantity = models.FloatField(validators=[MinValueValidator(0.1)])
    unit = models.CharField(max_length=20, default='pieces')
    estimated_price = models.DecimalField(max_digits=8, decimal_places=2, default=Decimal('0.00'))
    actual_price = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')
    notes = models.TextField(blank=True)
    is_purchased = models.BooleanField(default=False)
    purchased_at = models.DateTimeField(null=True, blank=True)
    added_by_voice = models.BooleanField(default=False)
    barcode = models.CharField(max_length=50, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['category__sort_order', 'priority', 'name']

    def __str__(self):
        return f"{self.quantity} {self.unit} {self.name}"

    @property
    def total_estimated_cost(self):
        return self.estimated_price * Decimal(str(self.quantity))

    @property
    def total_actual_cost(self):
        if self.actual_price:
            return self.actual_price * Decimal(str(self.quantity))
        return Decimal('0.00')


class PriceHistory(models.Model):
    """Track price history for items at different stores"""
    item_name = models.CharField(max_length=200)
    store = models.ForeignKey(Store, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    unit = models.CharField(max_length=20)
    recorded_by = models.ForeignKey(User, on_delete=models.CASCADE)
    recorded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-recorded_at']

    def __str__(self):
        return f"{self.item_name} - ${self.price}/{self.unit} at {self.store.name}"


class Budget(models.Model):
    """Monthly/weekly grocery budgets"""
    PERIOD_CHOICES = [
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='budgets')
    period = models.CharField(max_length=10, choices=PERIOD_CHOICES, default='monthly')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    start_date = models.DateField()
    end_date = models.DateField()
    category = models.ForeignKey(GroceryCategory, on_delete=models.SET_NULL, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.period} budget: ${self.amount}"

    @property
    def spent_amount(self):
        # Calculate actual spending in this budget period
        grocery_lists = GroceryList.objects.filter(
            user=self.user,
            created_at__range=[self.start_date, self.end_date]
        )
        total_spent = sum(gl.total_actual_cost for gl in grocery_lists)
        return total_spent

    @property
    def remaining_amount(self):
        return self.amount - self.spent_amount

    @property
    def is_over_budget(self):
        return self.spent_amount > self.amount
