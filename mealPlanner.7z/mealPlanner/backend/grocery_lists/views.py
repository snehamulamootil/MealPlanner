from rest_framework import generics, status, filters
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Q, Sum
from datetime import datetime
import re
from .models import Store, GroceryCategory, GroceryList, GroceryItem, PriceHistory, Budget
from .serializers import (
    StoreSerializer, GroceryCategorySerializer, GroceryListSerializer,
    GroceryListCreateSerializer, GroceryItemSerializer, PriceHistorySerializer,
    BudgetSerializer, VoiceGroceryItemSerializer
)


class StoreListCreateView(generics.ListCreateAPIView):
    queryset = Store.objects.all()
    serializer_class = StoreSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [filters.SearchFilter]
    search_fields = ['name', 'address']


class GroceryCategoryListView(generics.ListCreateAPIView):
    queryset = GroceryCategory.objects.all()
    serializer_class = GroceryCategorySerializer
    permission_classes = [IsAuthenticated]


class GroceryListListCreateView(generics.ListCreateAPIView):
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'description']
    filterset_fields = ['status', 'store', 'is_shared']
    ordering_fields = ['created_at', 'due_date', 'name']
    ordering = ['-created_at']

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return GroceryListCreateSerializer
        return GroceryListSerializer

    def get_queryset(self):
        return GroceryList.objects.filter(
            Q(user=self.request.user) | Q(shared_with=self.request.user)
        ).distinct().prefetch_related('items__category', 'store')

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class GroceryListDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = GroceryListSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return GroceryList.objects.filter(
            Q(user=self.request.user) | Q(shared_with=self.request.user)
        ).distinct()


class GroceryItemListCreateView(generics.ListCreateAPIView):
    serializer_class = GroceryItemSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    search_fields = ['name', 'brand', 'notes']
    filterset_fields = ['category', 'priority', 'is_purchased']

    def get_queryset(self):
        grocery_list_id = self.kwargs.get('grocery_list_id')
        return GroceryItem.objects.filter(
            grocery_list_id=grocery_list_id,
            grocery_list__user=self.request.user
        )

    def perform_create(self, serializer):
        grocery_list_id = self.kwargs.get('grocery_list_id')
        grocery_list = GroceryList.objects.get(
            id=grocery_list_id, user=self.request.user
        )
        serializer.save(grocery_list=grocery_list)


class GroceryItemDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = GroceryItemSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return GroceryItem.objects.filter(
            grocery_list__user=self.request.user
        )


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def mark_item_purchased(request, item_id):
    """Mark grocery item as purchased"""
    try:
        item = GroceryItem.objects.get(
            id=item_id, grocery_list__user=request.user
        )
        item.is_purchased = True
        item.purchased_at = datetime.now()
        if 'actual_price' in request.data:
            item.actual_price = request.data['actual_price']
        item.save()

        return Response({
            'message': 'Item marked as purchased',
            'item': GroceryItemSerializer(item).data
        })
    except GroceryItem.DoesNotExist:
        return Response({'error': 'Item not found'}, status=status.HTTP_404_NOT_FOUND)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_voice_grocery_item(request):
    """Add grocery item using voice input with NLP parsing"""
    serializer = VoiceGroceryItemSerializer(data=request.data)

    if serializer.is_valid():
        text_input = serializer.validated_data['text_input']
        grocery_list_id = serializer.validated_data['grocery_list_id']

        try:
            grocery_list = GroceryList.objects.get(
                id=grocery_list_id, user=request.user
            )

            # Simple NLP parsing for grocery items
            parsed_items = parse_grocery_text(text_input)
            created_items = []

            for item_data in parsed_items:
                grocery_item = GroceryItem.objects.create(
                    grocery_list=grocery_list,
                    name=item_data['name'],
                    quantity=item_data['quantity'],
                    unit=item_data['unit'],
                    priority=item_data.get('priority', 'medium'),
                    added_by_voice=True
                )
                created_items.append(GroceryItemSerializer(grocery_item).data)

            return Response({
                'message': f'Added {len(created_items)} items from voice input',
                'items': created_items
            })

        except GroceryList.DoesNotExist:
            return Response({'error': 'Grocery list not found'}, status=status.HTTP_404_NOT_FOUND)

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


def parse_grocery_text(text):
    """Simple NLP parser for grocery items"""
    items = []

    # Split by common separators
    text_items = re.split(r'[,;]|\sand\s', text.lower())

    for item_text in text_items:
        item_text = item_text.strip()
        if not item_text:
            continue

        # Extract quantity and unit
        quantity_match = re.search(r'(\d+(?:\.\d+)?)\s*(\w+)?\s*(.+)', item_text)

        if quantity_match:
            quantity = float(quantity_match.group(1))
            unit = quantity_match.group(2) if quantity_match.group(2) else 'pieces'
            name = quantity_match.group(3).strip()
        else:
            quantity = 1
            unit = 'pieces'
            name = item_text

        # Determine priority from keywords
        priority = 'medium'
        if any(word in item_text for word in ['urgent', 'asap', 'immediately']):
            priority = 'urgent'
        elif any(word in item_text for word in ['important', 'need']):
            priority = 'high'

        items.append({
            'name': name.title(),
            'quantity': quantity,
            'unit': unit,
            'priority': priority
        })

    return items


class BudgetListCreateView(generics.ListCreateAPIView):
    serializer_class = BudgetSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['period', 'is_active', 'category']

    def get_queryset(self):
        return Budget.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class PriceHistoryListCreateView(generics.ListCreateAPIView):
    serializer_class = PriceHistorySerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    search_fields = ['item_name', 'store__name']
    filterset_fields = ['store']

    def get_queryset(self):
        return PriceHistory.objects.all().select_related('store', 'recorded_by')

    def perform_create(self, serializer):
        serializer.save(recorded_by=self.request.user)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def budget_overview(request):
    """Get user's budget overview and spending analytics"""
    budgets = Budget.objects.filter(user=request.user, is_active=True)

    overview = {
        'total_monthly_budget': budgets.filter(period='monthly').aggregate(
            total=Sum('amount')
        )['total'] or 0,
        'total_weekly_budget': budgets.filter(period='weekly').aggregate(
            total=Sum('amount')
        )['total'] or 0,
        'budgets': BudgetSerializer(budgets, many=True).data,
        'recent_spending': []
    }

    # Get recent grocery lists with spending
    recent_lists = GroceryList.objects.filter(
        user=request.user, status='completed'
    ).order_by('-updated_at')[:5]

    for grocery_list in recent_lists:
        overview['recent_spending'].append({
            'name': grocery_list.name,
            'amount': grocery_list.total_actual_cost,
            'date': grocery_list.updated_at
        })

    return Response(overview)
