from rest_framework import serializers
from .models import Store, GroceryCategory, GroceryList, GroceryItem, PriceHistory, Budget


class StoreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Store
        fields = '__all__'


class GroceryCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = GroceryCategory
        fields = '__all__'


class GroceryItemSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    total_estimated_cost = serializers.ReadOnlyField()
    total_actual_cost = serializers.ReadOnlyField()

    class Meta:
        model = GroceryItem
        fields = ('id', 'name', 'category', 'category_name', 'brand', 'quantity', 'unit',
                 'estimated_price', 'actual_price', 'priority', 'notes', 'is_purchased',
                 'purchased_at', 'added_by_voice', 'barcode', 'total_estimated_cost',
                 'total_actual_cost', 'created_at', 'updated_at')


class GroceryListSerializer(serializers.ModelSerializer):
    items = GroceryItemSerializer(many=True, read_only=True)
    store_name = serializers.CharField(source='store.name', read_only=True)
    total_estimated_cost = serializers.ReadOnlyField()
    total_actual_cost = serializers.ReadOnlyField()
    completion_percentage = serializers.ReadOnlyField()
    is_over_budget = serializers.ReadOnlyField()

    class Meta:
        model = GroceryList
        fields = ('id', 'name', 'description', 'status', 'budget_limit', 'store', 'store_name',
                 'due_date', 'is_shared', 'shared_with', 'items', 'total_estimated_cost',
                 'total_actual_cost', 'completion_percentage', 'is_over_budget',
                 'created_at', 'updated_at')
        read_only_fields = ('user',)


class GroceryListCreateSerializer(serializers.ModelSerializer):
    items = serializers.ListField(write_only=True, required=False)

    class Meta:
        model = GroceryList
        fields = ('name', 'description', 'status', 'budget_limit', 'store', 'due_date',
                 'is_shared', 'shared_with', 'items')

    def create(self, validated_data):
        items_data = validated_data.pop('items', [])
        grocery_list = GroceryList.objects.create(**validated_data)

        for item_data in items_data:
            GroceryItem.objects.create(grocery_list=grocery_list, **item_data)

        return grocery_list


class PriceHistorySerializer(serializers.ModelSerializer):
    store_name = serializers.CharField(source='store.name', read_only=True)
    recorded_by_name = serializers.CharField(source='recorded_by.username', read_only=True)

    class Meta:
        model = PriceHistory
        fields = ('id', 'item_name', 'store', 'store_name', 'price', 'unit',
                 'recorded_by', 'recorded_by_name', 'recorded_at')
        read_only_fields = ('recorded_by',)


class BudgetSerializer(serializers.ModelSerializer):
    spent_amount = serializers.ReadOnlyField()
    remaining_amount = serializers.ReadOnlyField()
    is_over_budget = serializers.ReadOnlyField()
    category_name = serializers.CharField(source='category.name', read_only=True)

    class Meta:
        model = Budget
        fields = ('id', 'period', 'amount', 'start_date', 'end_date', 'category',
                 'category_name', 'is_active', 'spent_amount', 'remaining_amount',
                 'is_over_budget', 'created_at')
        read_only_fields = ('user',)


class VoiceGroceryItemSerializer(serializers.Serializer):
    """Serializer for voice-added grocery items"""
    text_input = serializers.CharField()
    grocery_list_id = serializers.IntegerField()

    def validate_text_input(self, value):
        if len(value.strip()) < 2:
            raise serializers.ValidationError("Text input too short")
        return value.strip()
