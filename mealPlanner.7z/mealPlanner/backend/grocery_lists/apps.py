from django.apps import AppConfig


class GroceryListsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'grocery_lists'
