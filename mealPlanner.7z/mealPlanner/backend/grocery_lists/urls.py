from django.urls import path
from . import views

urlpatterns = [
    path('stores/', views.StoreListCreateView.as_view(), name='store-list'),
    path('categories/', views.GroceryCategoryListView.as_view(), name='grocery-category-list'),
    path('', views.GroceryListListCreateView.as_view(), name='grocery-list-list'),
    path('<int:pk>/', views.GroceryListDetailView.as_view(), name='grocery-list-detail'),
    path('<int:grocery_list_id>/items/', views.GroceryItemListCreateView.as_view(), name='grocery-item-list'),
    path('items/<int:pk>/', views.GroceryItemDetailView.as_view(), name='grocery-item-detail'),
    path('items/<int:item_id>/purchase/', views.mark_item_purchased, name='mark-item-purchased'),
    path('voice/add-item/', views.add_voice_grocery_item, name='add-voice-item'),
    path('budgets/', views.BudgetListCreateView.as_view(), name='budget-list'),
    path('budgets/overview/', views.budget_overview, name='budget-overview'),
    path('price-history/', views.PriceHistoryListCreateView.as_view(), name='price-history'),
]
